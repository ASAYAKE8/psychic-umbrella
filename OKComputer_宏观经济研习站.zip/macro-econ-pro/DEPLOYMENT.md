# MacroEcon Pro 部署指南

## 🚀 部署选项

### 选项一：Vercel一键部署（推荐）

点击下面的按钮，一键部署到Vercel：

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-org/macro-econ-pro)

**步骤：**
1. 点击按钮
2. 登录Vercel账号
3. 配置项目设置
4. 点击部署
5. 等待部署完成

### 选项二：手动部署到Vercel

#### 1. 准备工作
```bash
# 确保项目已推送到GitHub
git remote add origin https://github.com/your-org/macro-econ-pro.git
git push -u origin main
```

#### 2. Vercel部署
```bash
# 安装Vercel CLI
npm i -g vercel

# 登录Vercel
vercel login

# 部署项目
vercel --prod
```

### 选项三：其他平台部署

#### Netlify部署
```bash
# 安装Netlify CLI
npm i -g netlify-cli

# 登录Netlify
netlify login

# 部署
netlify deploy --prod --dir=.next
```

#### 其他静态托管
```bash
# 构建项目
npm run build

# 导出静态文件
npm run export

# 部署到静态托管
# 将out/目录上传到托管平台
```

## 🔧 环境配置

### 必需环境变量

创建 `.env.local` 文件：

```env
# 基础配置
NEXT_PUBLIC_SITE_URL=https://your-domain.com
NEXT_PUBLIC_APP_NAME=MacroEcon Pro
NEXT_PUBLIC_APP_VERSION=1.0.0

# 分析工具（可选）
# NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
# NEXT_PUBLIC_UMAMI_ID=your-umami-id
```

### Vercel环境变量配置

1. 进入Vercel项目设置
2. 点击"Environment Variables"
3. 添加必需的环境变量
4. 保存并重新部署

## 📊 部署后配置

### 1. 域名配置
- 在Vercel中添加自定义域名
- 配置DNS记录
- 启用HTTPS

### 2. 分析工具
- Google Analytics
- Vercel Analytics
- 其他分析工具

### 3. SEO优化
- Google Search Console
- Bing Webmaster Tools
- 站点地图提交

### 4. 监控配置
- 错误监控 (Sentry)
- 性能监控 (Lighthouse CI)
- 用户行为分析

## 🎯 部署验证

### 1. 功能验证
访问以下页面，确保功能正常：
- [ ] 首页: https://your-domain.com
- [ ] 课程: https://your-domain.com/courses
- [ ] 知识库: https://your-domain.com/knowledge
- [ ] 政策雷达: https://your-domain.com/policy
- [ ] 收藏夹: https://your-domain.com/favorites
- [ ] 搜索: https://your-domain.com/search
- [ ] 关于: https://your-domain.com/about

### 2. 功能测试
- [ ] 深色模式切换
- [ ] 搜索功能
- [ ] 收藏功能
- [ ] 间隔重复复习
- [ ] Anki导出
- [ ] 响应式设计

### 3. 性能测试
- [ ] Lighthouse评分 ≥95
- [ ] 首次内容绘制 ≤1.5s
- [ ] 移动端体验良好
- [ ] 无障碍检查通过

## 🔍 故障排查

### 常见问题

#### 1. 构建失败
```bash
# 检查Node.js版本
node --version  # 需要18+

# 清除缓存
rm -rf node_modules .next
npm install

# 重新构建
npm run build
```

#### 2. 部署失败
- 检查环境变量配置
- 确认GitHub仓库连接
- 查看部署日志

#### 3. 功能异常
- 检查浏览器控制台
- 查看网络请求
- 确认API端点

#### 4. 性能问题
- 运行Lighthouse检查
- 分析构建产物
- 优化图片和资源

## 📈 上线后监控

### 1. 性能监控
- Vercel Analytics
- Google Analytics
- Lighthouse CI

### 2. 错误监控
- Sentry
- LogRocket
- 自定义错误处理

### 3. 用户反馈
- 反馈表单
- 用户调研
- 社区讨论

## 🔄 持续部署

### 1. 自动部署
```bash
# 每次推送自动部署
git push origin main
```

### 2. 预览部署
```bash
# 创建预览环境
git checkout -b feature/new-feature
git push origin feature/new-feature
```

### 3. 回滚部署
```bash
# Vercel控制台回滚
# 或使用CLI
vercel --prod --force
```

## 📋 部署检查清单

部署前检查：
- [ ] 代码已推送到GitHub
- [ ] 环境变量已配置
- [ ] 构建测试通过
- [ ] 功能测试通过
- [ ] 性能测试通过

部署后检查：
- [ ] 所有页面可访问
- [ ] 核心功能正常
- [ ] 性能指标达标
- [ ] 无障碍检查通过
- [ ] 移动端体验良好

## 🎉 部署完成

部署成功后，您将拥有一个功能完整的宏观经济学学习平台！

**访问地址**: https://your-domain.com

---

## 📞 技术支持

如遇到部署问题，请通过以下方式获取帮助：
- 📧 Email: contact@macro-econ-pro.com
- 🐙 GitHub Issues
- 💬 社区讨论

**祝您部署顺利！** 🚀