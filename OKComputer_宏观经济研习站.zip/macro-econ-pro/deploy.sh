#!/bin/bash

# MacroEcon Pro 部署脚本

set -e

echo "🚀 开始部署 MacroEcon Pro..."

# 检查Node.js版本
NODE_VERSION=$(node --version | cut -d'v' -f2)
REQUIRED_NODE_VERSION="18.0.0"

if [ "$(printf '%s\n' "$REQUIRED_NODE_VERSION" "$NODE_VERSION" | sort -V | head -n1)" != "$REQUIRED_NODE_VERSION" ]; then
    echo "❌ Node.js版本过低，需要18.0.0或更高版本"
    exit 1
fi

echo "✅ Node.js版本检查通过: $NODE_VERSION"

# 安装依赖
echo "📦 安装依赖..."
npm ci

# 代码质量检查
echo "🔍 运行代码质量检查..."
npm run lint

# 类型检查
echo "🔍 运行类型检查..."
npm run type-check

# 运行测试
echo "🧪 运行测试..."
npm test

# 构建项目
echo "🏗️ 构建项目..."
npm run build

# 检查构建结果
if [ ! -d ".next" ]; then
    echo "❌ 构建失败: .next目录不存在"
    exit 1
fi

echo "✅ 构建成功"

# 检查文件大小
echo "📊 检查构建文件大小..."
BUILD_SIZE=$(du -sh .next | cut -f1)
echo "📦 构建大小: $BUILD_SIZE"

# 运行Lighthouse检查（可选）
if command -v lhci &> /dev/null; then
    echo "🔦 运行Lighthouse检查..."
    npx lhci autorun
else
    echo "⚠️  Lighthouse CLI未安装，跳过性能检查"
fi

# 部署到Vercel
echo "🚀 部署到Vercel..."
if command -v vercel &> /dev/null; then
    vercel --prod
else
    echo "📋 请使用以下命令手动部署:"
    echo "vercel --prod"
fi

echo "🎉 部署完成！"
echo "🔗 访问: https://macro-econ-pro.vercel.app"