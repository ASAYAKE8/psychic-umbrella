# MacroEcon Pro 快速启动指南

## 🚀 5分钟快速启动

### 方法一：一键部署（推荐）

点击下面的按钮，一键部署到Vercel：

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-org/macro-econ-pro)

### 方法二：本地开发

#### 1. 克隆项目
```bash
git clone https://github.com/your-org/macro-econ-pro.git
cd macro-econ-pro
```

#### 2. 安装依赖
```bash
npm install
```

#### 3. 启动开发服务器
```bash
npm run dev
```

#### 4. 访问应用
打开浏览器访问: http://localhost:3000

---

## 📚 功能快速导览

### 1. 首页 (http://localhost:3000)
- 展示精选课程和知识点
- 智能复习系统入口
- 平台特色介绍

### 2. 课程中心 (http://localhost:3000/courses)
- 20门精品课程
- 支持按分类、难度筛选
- 网格/列表视图切换

### 3. 知识库 (http://localhost:3000/knowledge)
- 200+ 核心知识点
- 每条300字精讲
- 支持搜索和筛选

### 4. 政策雷达 (http://localhost:3000/policy)
- 最新政策动态
- 影响评级显示
- 实时更新

### 5. 收藏夹 (http://localhost:3000/favorites)
- 管理收藏内容
- 学习进度跟踪
- 间隔重复复习

### 6. 全局搜索 (http://localhost:3000/search)
- 全文搜索
- 实时建议
- 高级筛选

---

## 🎯 核心功能体验

### 1. 间隔重复学习
1. 收藏任意课程/知识点
2. 进入收藏夹的"复习"标签
3. 开始智能复习
4. 根据掌握程度选择复习间隔

### 2. Anki卡片导出
1. 进入知识库页面
2. 点击"导出Anki卡片"
3. 下载ZIP文件
4. 导入Anki应用学习

### 3. 深色模式
1. 点击顶部导航栏的主题切换按钮
2. 或在系统设置中切换主题
3. 网站会自动同步系统主题

### 4. 全文搜索
1. 在任意页面使用搜索框
2. 输入关键词
3. 查看实时搜索结果
4. 使用筛选器精确查找

---

## 🔧 开发配置

### 环境变量
复制 `.env.example` 为 `.env.local`:
```bash
cp .env.example .env.local
```

### 代码质量检查
```bash
# ESLint检查
npm run lint

# TypeScript检查
npm run type-check

# 运行测试
npm test
```

### 构建生产版本
```bash
npm run build
```

---

## 📊 数据概览

### 课程内容
- GDP核算体系精讲
- CPI与通胀分析
- 货币政策工具箱
- 财政政策深度解析
- 汇率决定理论
- IS-LM模型实战
- 失业理论全解
- 通货膨胀治理
- 经济周期理论
- 国际贸易理论
- 金融市场与机构
- 经济增长理论
- 产业组织理论
- 区域经济学
- 环境经济学
- 行为经济学入门
- 数字经济学
- 中国经济改革史
- 金融危机与防范
- 新发展格局

### 核心知识点
- GDP、CPI、货币政策、财政政策
- 通货膨胀、失业率、汇率、利率
- IS-LM模型、经济周期、国际收支
- 乘数效应、菲利普斯曲线、经济增长
- 比较优势、市场失灵、供给侧改革
- 数字经济、双循环、系统性风险

### 最新政策
- 2024年政府工作报告
- 央行降准降息政策
- 房地产白名单支持
- 新能源汽车购置税减免
- 稳就业政策组合拳
- 外贸稳规模优结构
- 碳达峰行动方案
- 数字经济发展规划
- 数据要素市场培育
- 自贸试验区深化改革

---

## 🎨 设计特色

### 视觉风格
- **主色调**: 深蓝 + 金色
- **字体**: SF Pro Display + 思源黑体
- **动效**: 流畅过渡动画
- **布局**: 瑞士网格系统

### 交互体验
- 响应式设计
- 无障碍支持
- 键盘导航
- 语音朗读

---

## 📞 获取帮助

### 文档资源
- [README.md](README.md) - 项目详细介绍
- [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md) - 技术架构概览
- [docs/](docs/) - 详细文档

### 联系方式
- 📧 Email: contact@macro-econ-pro.com
- 🐙 GitHub: [issues](https://github.com/your-org/macro-econ-pro/issues)
- 💬 社区讨论

### 常见问题
1. **Q: 如何导入Anki卡片？**
   A: 下载ZIP文件，解压后在Anki中导入TXT文件

2. **Q: 复习间隔如何计算？**
   A: 基于艾宾浩斯遗忘曲线，根据掌握程度智能安排

3. **Q: 支持移动端吗？**
   A: 完全响应式设计，支持手机、平板、桌面

4. **Q: 数据会丢失吗？**
   A: 学习数据存储在本地，建议定期备份

---

## 🔮 后续规划

### 即将推出
- [ ] 更多精品课程
- [ ] AI学习助手
- [ ] 学习社区
- [ ] 移动端App
- [ ] 数据同步功能

### 技术升级
- [ ] PWA支持
- [ ] 离线缓存
- [ ] 性能优化
- [ ] 国际化支持

---

**开始使用 MacroEcon Pro，开启您的宏观经济学学习之旅！** 🚀