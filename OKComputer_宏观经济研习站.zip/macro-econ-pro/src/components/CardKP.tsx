'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Brain, Tag, Heart, BookOpen } from 'lucide-react'
import { KnowledgePoint } from '@/types'
import { useFavorites } from '@/hooks/useFavorites'

interface CardKPProps {
  kp: KnowledgePoint
  index?: number
}

export function CardKP({ kp, index = 0 }: CardKPProps) {
  const { isFavorite, addFavorite, removeFavorite } = useFavorites()
  const isFav = isFavorite('kp', kp.id)

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (isFav) {
      removeFavorite('kp', kp.id)
    } else {
      addFavorite('kp', kp.id)
    }
  }

  const getCategoryColor = (category: string) => {
    const colors = {
      '核心指标': 'bg-blue-500',
      '核心概念': 'bg-green-500',
      '政策分析': 'bg-purple-500',
      '经济理论': 'bg-indigo-500',
      '国际金融': 'bg-cyan-500',
      '金融市场': 'bg-teal-500',
      '国际贸易': 'bg-orange-500',
      '微观基础': 'bg-pink-500',
      '中国政策': 'bg-red-500',
      '前沿理论': 'bg-violet-500',
      '金融稳定': 'bg-amber-500',
      '经济模型': 'bg-emerald-500',
    }
    return colors[category as keyof typeof colors] || 'bg-gray-500'
  }

  const getDifficultyDots = (difficulty: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <div
        key={i}
        className={`w-2 h-2 rounded-full ${
          i < difficulty ? 'bg-gray-800 dark:bg-gray-200' : 'bg-gray-300 dark:bg-gray-600'
        }`}
      />
    ))
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -4 }}
      className="group relative bg-white dark:bg-primary-800 rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 overflow-hidden"
    >
      <Link href={`/knowledge/${kp.id}`} className="block">
        {/* Header */}
        <div className="flex items-start justify-between p-6 pb-4">
          {/* Category Indicator */}
          <div className="flex items-center gap-3">
            <div className={`w-4 h-4 rounded-full ${getCategoryColor(kp.category)}`} />
            <div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-accent-600 dark:group-hover:text-accent-400 transition-colors">
                {kp.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{kp.category}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Difficulty */}
            <div className="flex gap-1">
              {getDifficultyDots(kp.difficulty)}
            </div>

            {/* Favorite */}
            <button
              onClick={handleFavoriteClick}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-primary-700 transition-colors"
              aria-label={isFav ? '取消收藏' : '收藏'}
            >
              <Heart
                className={`w-4 h-4 ${
                  isFav
                    ? 'fill-red-500 text-red-500'
                    : 'text-gray-400 hover:text-red-500'
                } transition-colors`}
              />
            </button>
          </div>
        </div>

        {/* Summary */}
        <div className="px-6 pb-4">
          <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
            {kp.summary}
          </p>
        </div>

        {/* Tags */}
        <div className="px-6 pb-4">
          <div className="flex flex-wrap gap-2">
            {kp.tags.slice(0, 4).map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 px-2 py-1 bg-primary-100 dark:bg-primary-700 text-primary-700 dark:text-primary-300 text-xs rounded-md"
              >
                <Tag className="w-3 h-3" />
                {tag}
              </span>
            ))}
            {kp.tags.length > 4 && (
              <span className="px-2 py-1 text-xs text-gray-500 dark:text-gray-400">
                +{kp.tags.length - 4}
              </span>
            )}
          </div>
        </div>

        {/* Meta Info */}
        <div className="px-6 pb-6">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Brain className="w-4 h-4" />
                <span>难度 {kp.difficulty}/5</span>
              </div>
              {kp.formula && (
                <div className="flex items-center gap-1">
                  <BookOpen className="w-4 h-4" />
                  <span>含公式</span>
                </div>
              )}
            </div>
            <span>300字精讲</span>
          </div>
        </div>

        {/* Formula Preview */}
        {kp.formula && (
          <div className="mx-6 mb-6 p-3 bg-gray-50 dark:bg-primary-700 rounded-lg">
            <div className="text-center">
              <code className="text-sm font-mono text-gray-800 dark:text-gray-200">
                {kp.formula}
              </code>
            </div>
          </div>
        )}
      </Link>

      {/* Hover Effect Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-accent-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
    </motion.div>
  )
}