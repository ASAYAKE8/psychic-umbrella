'use client'

import { useState, useEffect, useRef } from 'react'
import { Search, X, TrendingUp, Clock } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useSearch } from '@/hooks/useSearch'
import Link from 'next/link'

export function SearchBox() {
  const { query, setQuery, results, isSearching, clearSearch } = useSearch()
  const [isOpen, setIsOpen] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // 热门搜索词
  const trendingSearches = [
    'GDP核算',
    '货币政策',
    '通货膨胀',
    '财政政策',
    '汇率机制',
    '经济周期',
  ]

  // 最近搜索
  const recentSearches = [
    'CPI计算',
    '利率市场化',
    '供给侧改革',
  ]

  // 处理输入变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setQuery(value)
    setShowSuggestions(value.length === 0)
  }

  // 处理输入聚焦
  const handleInputFocus = () => {
    setIsOpen(true)
    setShowSuggestions(query.length === 0)
  }

  // 处理输入失焦
  const handleInputBlur = () => {
    setTimeout(() => {
      setIsOpen(false)
      setShowSuggestions(false)
    }, 200)
  }

  // 处理清除搜索
  const handleClear = () => {
    clearSearch()
    setShowSuggestions(true)
    inputRef.current?.focus()
  }

  // 处理搜索建议点击
  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion)
    setShowSuggestions(false)
  }

  // 点击外部关闭
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false)
        setShowSuggestions(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div ref={containerRef} className="relative w-full max-w-2xl mx-auto">
      {/* Search Input */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          placeholder="搜索课程、知识点、政策..."
          className="block w-full pl-10 pr-10 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-accent-500 focus:border-accent-500"
        />

        {/* Clear Button */}
        {query && (
          <button
            onClick={handleClear}
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
          >
            <X className="h-5 w-5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" />
          </button>
        )}
      </div>

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-50 top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg overflow-hidden"
          >
            {/* Search Suggestions */}
            {showSuggestions && (
              <div className="p-4">
                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      最近搜索
                    </h3>
                    <div className="space-y-1">
                      {recentSearches.map((search) => (
                        <button
                          key={search}
                          onClick={() => handleSuggestionClick(search)}
                          className="w-full text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Trending Searches */}
                <div>
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-2 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    热门搜索
                  </h3>
                  <div className="grid grid-cols-2 gap-2">
                    {trendingSearches.map((search) => (
                      <button
                        key={search}
                        onClick={() => handleSuggestionClick(search)}
                        className="text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                      >
                        {search}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Search Results */}
            {!showSuggestions && query && (
              <div className="max-h-96 overflow-y-auto">
                {isSearching && (
                  <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                    搜索中...
                  </div>
                )}

                {!isSearching && results.length === 0 && (
                  <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                    未找到相关内容
                  </div>
                )}

                {!isSearching && results.length > 0 && (
                  <div>
                    <div className="px-4 py-2 bg-gray-50 dark:bg-gray-700 text-sm text-gray-600 dark:text-gray-400">
                      找到 {results.length} 个结果
                    </div>
                    {results.slice(0, 8).map((result, index) => (
                      <Link
                        key={`${result.type}-${result.item.id}`}
                        href={`/${result.type === 'kp' ? 'knowledge' : result.type === 'course' ? 'course' : 'policy'}/${
                          'slug' in result.item ? result.item.slug : result.item.id
                        }`}
                        onClick={() => setIsOpen(false)}
                        className="block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-600 last:border-b-0 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium text-accent-600 dark:text-accent-400">
                                {result.type === 'course' && '课程'}
                                {result.type === 'kp' && '知识点'}
                                {result.type === 'policy' && '政策'}
                              </span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {Math.round((1 - result.score) * 100)}% 匹配
                              </span>
                            </div>
                            <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                              {'title' in result.item ? result.item.title : '未知标题'}
                            </h4>
                            {'summary' in result.item && (
                              <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                                {result.item.summary}
                              </p>
                            )}
                          </div>
                        </div>
                      </Link>
                    ))}
                    {results.length > 8 && (
                      <div className="px-4 py-3 text-center">
                        <Link
                          href="/search"
                          onClick={() => setIsOpen(false)}
                          className="text-sm text-accent-600 dark:text-accent-400 hover:underline"
                        >
                          查看全部 {results.length} 个结果 →
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}