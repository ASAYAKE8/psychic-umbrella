'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Calendar, Building2, MapPin, Heart, ExternalLink } from 'lucide-react'
import { Policy } from '@/types'
import { useFavorites } from '@/hooks/useFavorites'
import { formatDate, formatRelativeTime } from '@/utils/date-format'

interface CardPolicyProps {
  policy: Policy
  index?: number
}

export function CardPolicy({ policy, index = 0 }: CardPolicyProps) {
  const { isFavorite, addFavorite, removeFavorite } = useFavorites()
  const isFav = isFavorite('policy', policy.id)

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (isFav) {
      removeFavorite('policy', policy.id)
    } else {
      addFavorite('policy', policy.id)
    }
  }

  const getImpactColor = (impact: Policy['impact']) => {
    switch (impact) {
      case '高':
        return 'bg-danger-500 text-white'
      case '中':
        return 'bg-warning-500 text-white'
      case '低':
        return 'bg-success-500 text-white'
      default:
        return 'bg-gray-500 text-white'
    }
  }

  const getRegionColor = (region: Policy['region']) => {
    const colors = {
      '全国': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      '华北': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      '华东': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      '华南': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      '西南': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      '西北': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      '东北': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300',
      '华中': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300',
    }
    return colors[region] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -4 }}
      className="group relative bg-white dark:bg-primary-800 rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 overflow-hidden"
    >
      <Link href={`/policy/${policy.id}`} className="block">
        {/* Header */}
        <div className="flex items-start justify-between p-6 pb-4">
          {/* Impact & Category */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getImpactColor(policy.impact)}`}>
                影响 {policy.impact}
              </span>
              <span className={`px-2 py-1 text-xs rounded-full ${getRegionColor(policy.region)}`}>
                {policy.region}
              </span>
            </div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-accent-600 dark:group-hover:text-accent-400 transition-colors leading-tight">
              {policy.title}
            </h3>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleFavoriteClick}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-primary-700 transition-colors"
              aria-label={isFav ? '取消收藏' : '收藏'}
            >
              <Heart
                className={`w-4 h-4 ${
                  isFav
                    ? 'fill-red-500 text-red-500'
                    : 'text-gray-400 hover:text-red-500'
                } transition-colors`}
              />
            </button>
          </div>
        </div>

        {/* Abstract */}
        <div className="px-6 pb-4">
          <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
            {policy.abstract}
          </p>
        </div>

        {/* Tags */}
        <div className="px-6 pb-4">
          <div className="flex flex-wrap gap-2">
            {policy.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 px-2 py-1 bg-primary-100 dark:bg-primary-700 text-primary-700 dark:text-primary-300 text-xs rounded-md"
              >
                {tag}
              </span>
            ))}
            {policy.tags.length > 3 && (
              <span className="px-2 py-1 text-xs text-gray-500 dark:text-gray-400">
                +{policy.tags.length - 3}
              </span>
            )}
          </div>
        </div>

        {/* Meta Info */}
        <div className="px-6 pb-6">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Building2 className="w-4 h-4" />
                <span>{policy.issuer}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(policy.pubDate)}</span>
              </div>
            </div>
            <span>{formatRelativeTime(policy.pubDate)}</span>
          </div>
        </div>

        {/* External Link */}
        <div className="px-6 pb-6">
          <a
            href={policy.fullURL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-sm text-accent-600 dark:text-accent-400 hover:underline"
            onClick={(e) => e.stopPropagation()}
          >
            查看原文
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </Link>

      {/* Hover Effect Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-accent-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
    </motion.div>
  )
}