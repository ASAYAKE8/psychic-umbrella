'use client'

import Link from 'next/link'
import { Github, Rss, Sun, Moon, Volume2, VolumeX } from 'lucide-react'
import { useTheme } from 'next-themes'
import { useState } from 'react'
import { motion } from 'framer-motion'

export function Footer() {
  const { theme, setTheme } = useTheme()
  const [isSpeaking, setIsSpeaking] = useState(false)

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const toggleSpeech = () => {
    if (isSpeaking) {
      speechSynthesis.cancel()
      setIsSpeaking(false)
    } else {
      const text = document.body.innerText
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'zh-CN'
      utterance.rate = 0.8
      utterance.pitch = 1
      
      utterance.onend = () => setIsSpeaking(false)
      utterance.onerror = () => setIsSpeaking(false)
      
      speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }

  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary-900 border-t border-primary-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-accent-500 rounded-lg flex items-center justify-center">
                <span className="text-primary-900 font-bold text-sm">宏</span>
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">MacroEcon Pro</h3>
                <p className="text-primary-300 text-xs">宏观经济研习站</p>
              </div>
            </div>
            <p className="text-primary-300 text-sm leading-relaxed mb-4">
              洞察宏观，决策先人一步。专业的宏观经济学学习平台，助您掌握经济规律，提升决策能力。
            </p>
            <div className="flex items-center gap-4">
              <button
                onClick={toggleTheme}
                className="p-2 text-primary-300 hover:text-white transition-colors"
                aria-label="切换主题"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={toggleSpeech}
                className="p-2 text-primary-300 hover:text-white transition-colors"
                aria-label="朗读全文"
              >
                {isSpeaking ? (
                  <Volume2 className="w-5 h-5 text-accent-500" />
                ) : (
                  <VolumeX className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">快速导航</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/courses" className="text-primary-300 hover:text-white transition-colors text-sm">
                  课程中心
                </Link>
              </li>
              <li>
                <Link href="/knowledge" className="text-primary-300 hover:text-white transition-colors text-sm">
                  知识库
                </Link>
              </li>
              <li>
                <Link href="/policy" className="text-primary-300 hover:text-white transition-colors text-sm">
                  政策雷达
                </Link>
              </li>
              <li>
                <Link href="/favorites" className="text-primary-300 hover:text-white transition-colors text-sm">
                  我的收藏
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-white font-semibold mb-4">学习资源</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-primary-300 hover:text-white transition-colors text-sm">
                  关于我们
                </Link>
              </li>
              <li>
                <a href="/api/rss" className="text-primary-300 hover:text-white transition-colors text-sm flex items-center gap-1">
                  <Rss className="w-4 h-4" />
                  RSS订阅
                </a>
              </li>
              <li>
                <a href="https://github.com/your-org/macro-econ-pro" className="text-primary-300 hover:text-white transition-colors text-sm flex items-center gap-1">
                  <Github className="w-4 h-4" />
                  开源代码
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-primary-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <div className="text-primary-400 text-sm text-center md:text-left">
              <p>
                © {currentYear} MacroEcon Pro. 保留所有权利。
              </p>
              <p className="mt-1">
                京ICP备12345678号 | 京公网安备11010802012345号
              </p>
            </div>

            {/* Links */}
            <div className="flex items-center gap-6 text-sm">
              <Link href="/about" className="text-primary-300 hover:text-white transition-colors">
                隐私政策
              </Link>
              <Link href="/about" className="text-primary-300 hover:text-white transition-colors">
                使用条款
              </Link>
              <Link href="/about" className="text-primary-300 hover:text-white transition-colors">
                联系我们
              </Link>
            </div>
          </div>
        </div>

        {/* Accessibility Notice */}
        <div className="mt-6 p-4 bg-primary-800/50 rounded-lg">
          <p className="text-xs text-primary-300 text-center">
            本网站遵循WCAG 2.1 AA级无障碍标准，致力于为所有用户提供平等的学习机会。
          </p>
        </div>
      </div>
    </footer>
  )
}