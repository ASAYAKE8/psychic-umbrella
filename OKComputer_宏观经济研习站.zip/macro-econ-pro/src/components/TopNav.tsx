'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Sun, Moon, Search, Menu, X, Volume2, VolumeX } from 'lucide-react'
import { useTheme } from 'next-themes'
import { useSearch } from '@/hooks/useSearch'

export function TopNav() {
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const { setQuery } = useSearch()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)

  const navItems = [
    { href: '/', label: '首页' },
    { href: '/courses', label: '课程' },
    { href: '/knowledge', label: '知识库' },
    { href: '/policy', label: '政策雷达' },
    { href: '/favorites', label: '收藏夹' },
    { href: '/about', label: '关于' },
  ]

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const toggleSpeech = () => {
    if (isSpeaking) {
      speechSynthesis.cancel()
      setIsSpeaking(false)
    } else {
      const text = document.body.innerText
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'zh-CN'
      utterance.rate = 0.8
      utterance.pitch = 1
      
      utterance.onend = () => setIsSpeaking(false)
      utterance.onerror = () => setIsSpeaking(false)
      
      speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value)
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-primary-900/95 backdrop-blur-sm border-b border-primary-700/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-accent-500 rounded-lg flex items-center justify-center">
              <span className="text-primary-900 font-bold text-sm">宏</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-white font-bold text-lg">MacroEcon Pro</h1>
              <p className="text-primary-300 text-xs">宏观经济研习站</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`relative px-3 py-2 text-sm font-medium transition-colors ${
                  pathname === item.href
                    ? 'text-accent-500'
                    : 'text-primary-300 hover:text-white'
                }`}
              >
                {pathname === item.href && (
                  <motion.div
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-500"
                    layoutId="activeTab"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                )}
                {item.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-3">
            {/* Search */}
            <div className="relative">
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="p-2 text-primary-300 hover:text-white transition-colors"
                aria-label="搜索"
              >
                <Search className="w-5 h-5" />
              </button>
              
              <AnimatePresence>
                {isSearchOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute top-full right-0 mt-2 w-64 bg-white dark:bg-primary-800 rounded-lg shadow-lg border border-primary-200 dark:border-primary-700 p-4"
                  >
                    <input
                      type="text"
                      placeholder="搜索课程、知识、政策..."
                      onChange={handleSearch}
                      className="w-full px-3 py-2 text-sm border border-primary-300 dark:border-primary-600 rounded-md bg-white dark:bg-primary-900 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-accent-500"
                      autoFocus
                    />
                    <Link
                      href="/search"
                      className="block mt-2 text-xs text-accent-600 dark:text-accent-400 hover:underline"
                      onClick={() => setIsSearchOpen(false)}
                    >
                      高级搜索 →
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Speech */}
            <button
              onClick={toggleSpeech}
              className="p-2 text-primary-300 hover:text-white transition-colors"
              aria-label="朗读全文"
            >
              {isSpeaking ? (
                <Volume2 className="w-5 h-5 text-accent-500" />
              ) : (
                <VolumeX className="w-5 h-5" />
              )}
            </button>

            {/* Theme */}
            <button
              onClick={toggleTheme}
              className="p-2 text-primary-300 hover:text-white transition-colors"
              aria-label="切换主题"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </button>

            {/* Mobile Menu */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-primary-300 hover:text-white transition-colors"
              aria-label="菜单"
            >
              {isMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-primary-900/98 backdrop-blur-sm border-t border-primary-700/20"
          >
            <div className="px-4 py-4 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-3 py-2 text-base font-medium rounded-md transition-colors ${
                    pathname === item.href
                      ? 'bg-accent-500/10 text-accent-500'
                      : 'text-primary-300 hover:text-white hover:bg-primary-800'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}