'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Brain, Clock, Target, TrendingUp, Skip, RotateCcw } from 'lucide-react'
import { useSpacedRep } from '@/hooks/useSpacedRep'
import { useFavorites } from '@/hooks/useFavorites'
import { ProgressRing } from './ProgressRing'
import { CardKP } from './CardKP'
import { CardCourse } from './CardCourse'
import { CardPolicy } from './CardPolicy'

export function SpacedRepetition() {
  const { todaysItems, retentionScore, progress, reviewItem, getNextReviewItem, skipItem } = useSpacedRep()
  const { favorites } = useFavorites()
  const [currentItem, setCurrentItem] = useState<any>(null)
  const [isReviewing, setIsReviewing] = useState(false)
  const [showAnswer, setShowAnswer] = useState(false)

  const startReview = () => {
    const nextItem = getNextReviewItem()
    if (nextItem) {
      setCurrentItem(nextItem)
      setIsReviewing(true)
      setShowAnswer(false)
    }
  }

  const handleReview = (performance: 'again' | 'hard' | 'good' | 'easy') => {
    if (currentItem) {
      reviewItem(currentItem.id, currentItem.type, performance)
      
      // 下一个复习项目
      const remainingItems = todaysItems.filter(item => item.id !== currentItem.id)
      if (remainingItems.length > 0) {
        setCurrentItem(remainingItems[0])
        setShowAnswer(false)
      } else {
        setIsReviewing(false)
        setCurrentItem(null)
      }
    }
  }

  const handleSkip = () => {
    if (currentItem) {
      skipItem(currentItem.id, currentItem.type)
      
      const remainingItems = todaysItems.filter(item => item.id !== currentItem.id)
      if (remainingItems.length > 0) {
        setCurrentItem(remainingItems[0])
        setShowAnswer(false)
      } else {
        setIsReviewing(false)
        setCurrentItem(null)
      }
    }
  }

  const renderItem = (item: any) => {
    switch (item.type) {
      case 'course':
        return <CardCourse course={item} />
      case 'kp':
        return <CardKP kp={item} />
      case 'policy':
        return <CardPolicy policy={item} />
      default:
        return null
    }
  }

  if (!isReviewing) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 flex items-center justify-center gap-3">
            <Brain className="w-8 h-8 text-accent-500" />
            间隔重复复习
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            基于艾宾浩斯遗忘曲线，科学安排复习时间
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-card">
            <div className="text-3xl font-bold text-accent-500 mb-2">
              {todaysItems.length}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              今日待复习
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-card">
            <div className="text-3xl font-bold text-green-500 mb-2">
              {progress.mastered}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              已掌握
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-card">
            <div className="text-3xl font-bold text-blue-500 mb-2">
              {progress.learning}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              学习中
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center shadow-card">
            <div className="text-3xl font-bold text-purple-500 mb-2">
              {Math.round(retentionScore * 100)}%
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              记忆保留率
            </div>
          </div>
        </div>

        {/* Progress Ring */}
        <div className="flex justify-center mb-8">
          <ProgressRing
            progress={retentionScore}
            size={200}
            color="#10B981"
            showPercentage={true}
          />
        </div>

        {/* Action Buttons */}
        <div className="text-center">
          {todaysItems.length > 0 ? (
            <button
              onClick={startReview}
              className="bg-accent-500 hover:bg-accent-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors flex items-center gap-2 mx-auto"
            >
              <Target className="w-5 h-5" />
              开始复习 ({todaysItems.length} 项)
            </button>
          ) : (
            <div className="text-center">
              <div className="text-6xl mb-4">🎉</div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                今日复习完成！
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                您已完成今日所有复习任务，继续保持！
              </p>
              <div className="flex items-center justify-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>下次复习：明天</span>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>记忆率：{Math.round(retentionScore * 100)}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  // Review Mode
  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600 dark:text-gray-400">
            进度: {todaysItems.length - todaysItems.filter(item => item.id !== currentItem?.id).length} / {todaysItems.length}
          </span>
          <span className="text-sm text-gray-600 dark:text-gray-400">
            剩余: {todaysItems.filter(item => item.id !== currentItem?.id).length} 项
          </span>
        </div>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div
            className="bg-accent-500 h-2 rounded-full transition-all duration-300"
            style={{
              width: `${((todaysItems.length - todaysItems.filter(item => item.id !== currentItem?.id).length) / todaysItems.length) * 100}%`,
            }}
          />
        </div>
      </div>

      {/* Current Item */}
      <div className="mb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentItem?.id}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            {currentItem && renderItem(currentItem)}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Review Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-card">
        <div className="text-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            您掌握得如何？
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            根据您的掌握程度选择相应的按钮
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <button
            onClick={() => handleReview('again')}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-3 rounded-lg font-medium transition-colors flex flex-col items-center gap-1"
          >
            <RotateCcw className="w-5 h-5" />
            <span>重来</span>
            <span className="text-xs opacity-80">1天后</span>
          </button>

          <button
            onClick={() => handleReview('hard')}
            className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-3 rounded-lg font-medium transition-colors flex flex-col items-center gap-1"
          >
            <Brain className="w-5 h-5" />
            <span>困难</span>
            <span className="text-xs opacity-80">3天后</span>
          </button>

          <button
            onClick={() => handleReview('good')}
            className="bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-lg font-medium transition-colors flex flex-col items-center gap-1"
          >
            <Target className="w-5 h-5" />
            <span>良好</span>
            <span className="text-xs opacity-80">7天后</span>
          </button>

          <button
            onClick={() => handleReview('easy')}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-3 rounded-lg font-medium transition-colors flex flex-col items-center gap-1"
          >
            <TrendingUp className="w-5 h-5" />
            <span>简单</span>
            <span className="text-xs opacity-80">15天后</span>
          </button>
        </div>

        {/* Skip Button */}
        <div className="text-center mt-4">
          <button
            onClick={handleSkip}
            className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 text-sm flex items-center gap-1 mx-auto transition-colors"
          >
            <Skip className="w-4 h-4" />
            跳过此项
          </button>
        </div>
      </div>
    </div>
  )
}