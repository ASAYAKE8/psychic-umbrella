'use client'

import { useRef, useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ZoomIn, ZoomOut, RefreshCw, Expand, Shrink } from 'lucide-react'
import { useMindMap, MindMapNode } from '@/hooks/useMindMap'

interface MindMapProps {
  nodes: MindMapNode[]
  width?: number
  height?: number
  onNodeClick?: (nodeId: string) => void
  className?: string
}

export function MindMap({
  nodes,
  width = 800,
  height = 600,
  onNodeClick,
  className = '',
}: MindMapProps) {
  const config = {
    width,
    height,
    nodeSpacing: 120,
    levelSpacing: 150,
    animationDuration: 300,
  }

  const {
    selectedNode,
    scale,
    offset,
    svgRef,
    toggleNode,
    selectNode,
    zoomIn,
    zoomOut,
    resetZoom,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleWheel,
    getNodePosition,
    getNodeConnections,
  } = useMindMap(nodes, config)

  const [isDragging, setIsDragging] = useState(false)

  const handleNodeClick = (nodeId: string) => {
    selectNode(nodeId)
    if (onNodeClick) {
      onNodeClick(nodeId)
    }
  }

  const getNodeColor = (node: MindMapNode) => {
    if (node.id === selectedNode) return '#F59E0B'
    if (node.level === 0) return '#2563EB'
    if (node.level === 1) return '#10B981'
    return '#6B7280'
  }

  const getNodeSize = (node: MindMapNode) => {
    if (node.level === 0) return 24
    if (node.level === 1) return 20
    return 16
  }

  return (
    <div className={`relative bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 ${className}`}>
      {/* Controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
        <button
          onClick={zoomIn}
          className="p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          aria-label="放大"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={zoomOut}
          className="p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          aria-label="缩小"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={resetZoom}
          className="p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          aria-label="重置"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* SVG Mind Map */}
      <svg
        ref={svgRef}
        width={width}
        height={height}
        className="cursor-move select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        {/* Transform group for pan and zoom */}
        <g transform={`translate(${offset.x}, ${offset.y}) scale(${scale})`}>
          {/* Connections */}
          {nodes.map((node) => {
            const connections = getNodeConnections(node.id)
            return connections.map((targetId) => {
              const targetPos = getNodePosition(targetId)
              const nodePos = getNodePosition(node.id)
              
              return (
                <motion.line
                  key={`${node.id}-${targetId}`}
                  x1={nodePos.x}
                  y1={nodePos.y}
                  x2={targetPos.x}
                  y2={targetPos.y}
                  stroke="#E5E7EB"
                  strokeWidth="2"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.5 }}
                />
              )
            })
          })}

          {/* Nodes */}
          {nodes.map((node) => {
            const isSelected = node.id === selectedNode
            const hasChildren = node.children && node.children.length > 0
            
            return (
              <g key={node.id}>
                {/* Node Circle */}
                <motion.circle
                  cx={node.x}
                  cy={node.y}
                  r={getNodeSize(node)}
                  fill={getNodeColor(node)}
                  stroke="white"
                  strokeWidth="3"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleNodeClick(node.id)}
                  className="cursor-pointer"
                />

                {/* Node Label */}
                <motion.text
                  x={node.x}
                  y={node.y + getNodeSize(node) + 20}
                  textAnchor="middle"
                  className="text-sm font-medium fill-gray-900 dark:fill-gray-100 pointer-events-none"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  {node.label}
                </motion.text>

                {/* Expand/Collapse Indicator */}
                {hasChildren && (
                  <motion.g
                    onClick={() => toggleNode(node.id)}
                    className="cursor-pointer"
                    whileHover={{ scale: 1.2 }}
                  >
                    <circle
                      cx={node.x + getNodeSize(node) - 5}
                      cy={node.y - getNodeSize(node) + 5}
                      r="8"
                      fill="white"
                      stroke="#374151"
                      strokeWidth="2"
                    />
                    <text
                      x={node.x + getNodeSize(node) - 5}
                      y={node.y - getNodeSize(node) + 5}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      className="text-xs font-bold fill-gray-700 pointer-events-none"
                    >
                      {node.expanded ? '−' : '+'}
                    </text>
                  </motion.g>
                )}

                {/* Selection Indicator */}
                {isSelected && (
                  <motion.circle
                    cx={node.x}
                    cy={node.y}
                    r={getNodeSize(node) + 5}
                    fill="none"
                    stroke="#F59E0B"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ repeat: Infinity, duration: 1 }}
                  />
                )}
              </g>
            )
          })}
        </g>
      </svg>

      {/* Info Panel */}
      <AnimatePresence>
        {selectedNode && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg p-4 shadow-lg max-w-xs"
          >
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
              {nodes.find(n => n.id === selectedNode)?.label}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              点击节点查看详细信息，或使用鼠标拖拽移动视图。
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Zoom Level Indicator */}
      <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-sm">
        {Math.round(scale * 100)}%
      </div>
    </div>
  )
}