'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Star, Clock, Tag, Heart } from 'lucide-react'
import { Course } from '@/types'
import { useFavorites } from '@/hooks/useFavorites'
import { formatDate } from '@/utils/date-format'

interface CardCourseProps {
  course: Course
  index?: number
}

export function CardCourse({ course, index = 0 }: CardCourseProps) {
  const { isFavorite, addFavorite, removeFavorite } = useFavorites()
  const isFav = isFavorite('course', course.id)

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (isFav) {
      removeFavorite('course', course.id)
    } else {
      addFavorite('course', course.id)
    }
  }

  const difficultyStars = Array.from({ length: 5 }, (_, i) => (
    <Star
      key={i}
      className={`w-4 h-4 ${
        i < course.difficulty
          ? 'fill-yellow-400 text-yellow-400'
          : 'text-gray-300 dark:text-gray-600'
      }`}
    />
  ))

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -4 }}
      className="group relative bg-white dark:bg-primary-800 rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 overflow-hidden"
    >
      <Link href={`/course/${course.slug}`} className="block">
        {/* Thumbnail */}
        <div className="relative h-48 bg-gradient-to-br from-primary-600 to-primary-800 overflow-hidden">
          <div className="absolute inset-0 bg-black/20" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white text-center">
              <h3 className="text-lg font-bold mb-1">{course.title}</h3>
              <p className="text-sm opacity-90">{course.tagline}</p>
            </div>
          </div>
          
          {/* Difficulty Badge */}
          <div className="absolute top-4 left-4">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg px-3 py-1">
              <div className="flex items-center gap-1">
                {difficultyStars}
              </div>
            </div>
          </div>

          {/* Duration Badge */}
          <div className="absolute top-4 right-4">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg px-3 py-1 flex items-center gap-1">
              <Clock className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-medium">{course.duration}分</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1 group-hover:text-accent-600 dark:group-hover:text-accent-400 transition-colors">
                {course.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{course.tagline}</p>
            </div>
            
            {/* Favorite Button */}
            <button
              onClick={handleFavoriteClick}
              className="ml-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-primary-700 transition-colors"
              aria-label={isFav ? '取消收藏' : '收藏'}
            >
              <Heart
                className={`w-5 h-5 ${
                  isFav
                    ? 'fill-red-500 text-red-500'
                    : 'text-gray-400 hover:text-red-500'
                } transition-colors`}
              />
            </button>
          </div>

          {/* Description */}
          <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-3">
            {course.description}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {course.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 px-2 py-1 bg-primary-100 dark:bg-primary-700 text-primary-700 dark:text-primary-300 text-xs rounded-md"
              >
                <Tag className="w-3 h-3" />
                {tag}
              </span>
            ))}
            {course.tags.length > 3 && (
              <span className="px-2 py-1 text-xs text-gray-500 dark:text-gray-400">
                +{course.tags.length - 3}
              </span>
            )}
          </div>

          {/* Meta Info */}
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span>讲师：{course.instructor}</span>
            <span>更新：{formatDate(course.updatedAt)}</span>
          </div>
        </div>
      </Link>

      {/* Hover Effect Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-accent-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
    </motion.div>
  )
}