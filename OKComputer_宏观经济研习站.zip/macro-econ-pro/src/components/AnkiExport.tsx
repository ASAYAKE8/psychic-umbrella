'use client'

import { useState } from 'react'
import { Download, BookOpen, AlertCircle } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { generateAnkiDeck, downloadBlob } from '@/utils/anki-export'
import { KnowledgePoint } from '@/types'

interface AnkiExportProps {
  knowledgePoints: KnowledgePoint[]
  deckName?: string
  className?: string
}

export function AnkiExport({
  knowledgePoints,
  deckName = '宏观经济学习卡片',
  className = '',
}: AnkiExportProps) {
  const [isExporting, setIsExporting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const convertToAnkiCards = (kps: KnowledgePoint[]) => {
    return kps.map((kp) => {
      // 提取核心内容（前3行）
      const bodyLines = kp.bodyMDX.split('\n').filter(line => line.trim())
      const coreContent = bodyLines.slice(0, 3).join('\n').replace(/\*\*/g, '').replace(/\*/g, '•')
      
      return {
        front: kp.title,
        back: `${kp.summary}\n\n${coreContent}`,
        tags: [kp.category, ...kp.tags],
      }
    })
  }

  const handleExport = async () => {
    if (knowledgePoints.length === 0) {
      setError('没有可导出的知识点')
      return
    }

    setIsExporting(true)
    setError(null)

    try {
      const cards = convertToAnkiCards(knowledgePoints)
      const blob = await generateAnkiDeck(cards, deckName)
      
      const timestamp = new Date().toISOString().slice(0, 10)
      const filename = `${deckName}_${timestamp}.zip`
      
      downloadBlob(blob, filename)
      
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 3000)
    } catch (err) {
      setError('导出失败，请重试')
      console.error('Anki export error:', err)
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 ${className}`}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Anki学习卡片导出
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            将知识点转换为Anki卡片，支持间隔重复学习
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
          <div className="text-2xl font-bold text-accent-600 dark:text-accent-400">
            {knowledgePoints.length}
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            知识点
          </div>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
          <div className="text-2xl font-bold text-accent-600 dark:text-accent-400">
            {Math.round(knowledgePoints.reduce((sum, kp) => sum + kp.difficulty, 0) / knowledgePoints.length || 0)}
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            平均难度
          </div>
        </div>
      </div>

      {/* Export Button */}
      <button
        onClick={handleExport}
        disabled={isExporting || knowledgePoints.length === 0}
        className="w-full bg-accent-500 hover:bg-accent-600 disabled:bg-gray-300 dark:disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
      >
        {isExporting ? (
          <>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
            />
            导出中...
          </>
        ) : (
          <>
            <Download className="w-5 h-5" />
            导出Anki卡片
          </>
        )}
      </button>

      {/* Error Message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center gap-2"
          >
            <AlertCircle className="w-5 h-5 text-red-500" />
            <span className="text-sm text-red-700 dark:text-red-300">{error}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Message */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg"
          >
            <p className="text-sm text-green-700 dark:text-green-300">
              导出成功！文件已下载到您的设备。
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Instructions */}
      <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
        <h4 className="font-medium text-blue-900 dark:text-blue-300 mb-2">
          使用说明
        </h4>
        <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
          <li>下载Anki应用（桌面版或手机版）</li>
          <li>解压下载的ZIP文件</li>
          <li>在Anki中点击"导入文件"</li>
          <li>选择TXT文件并设置导入选项</li>
          <li>开始您的间隔重复学习之旅！</li>
        </ol>
      </div>

      {/* Card Format */}
      <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
        <h4 className="font-medium text-gray-900 dark:text-white mb-2">
          卡片格式
        </h4>
        <div className="space-y-2 text-sm">
          <div>
            <span className="font-medium text-gray-700 dark:text-gray-300">正面：</span>
            <span className="text-gray-600 dark:text-gray-400">知识点标题</span>
          </div>
          <div>
            <span className="font-medium text-gray-700 dark:text-gray-300">背面：</span>
            <span className="text-gray-600 dark:text-gray-400">核心摘要 + 详细内容（前3行）</span>
          </div>
          <div>
            <span className="font-medium text-gray-700 dark:text-gray-300">标签：</span>
            <span className="text-gray-600 dark:text-gray-400">分类 + 关键词</span>
          </div>
        </div>
      </div>
    </div>
  )
}