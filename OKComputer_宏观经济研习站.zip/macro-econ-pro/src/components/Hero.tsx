'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { ArrowRight, Play } from 'lucide-react'

export function Hero() {
  const [displayedText, setDisplayedText] = useState('')
  const fullText = '洞察宏观，决策先人一步。'
  
  useEffect(() => {
    let index = 0
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setDisplayedText(fullText.slice(0, index + 1))
        index++
      } else {
        clearInterval(timer)
      }
    }, 100)

    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative min-h-[80vh] flex items-center justify-center bg-gradient-to-br from-primary-900 via-primary-800 to-primary-900 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, #f59e0b 0%, transparent 50%),
                           radial-gradient(circle at 75% 75%, #f59e0b 0%, transparent 50%)`,
          backgroundSize: '100px 100px',
        }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6"
        >
          <span className="block">看懂GDP、CPI、利率、汇率</span>
          <span className="block text-accent-500">世界运行不再神秘</span>
        </motion.h1>

        {/* Slogan */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mb-8"
        >
          <h2 className="text-xl md:text-2xl text-primary-300 mb-4">
            每天10分钟，成为宏观经济学通
          </h2>
          <div className="text-2xl md:text-3xl font-semibold text-accent-500 h-8">
            <span className="inline-block">{displayedText}</span>
            <motion.span
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className="inline-block w-1 h-8 bg-accent-500 ml-1"
            />
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
        >
          <Link
            href="/courses"
            className="group bg-accent-500 hover:bg-accent-400 text-primary-900 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center gap-2 transform hover:scale-105"
          >
            开始学习
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>
          
          <button className="group border-2 border-white/30 hover:border-white text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center gap-2 hover:bg-white/10">
            <Play className="w-5 h-5 group-hover:scale-110 transition-transform" />
            观看介绍
          </button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3, duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto"
        >
          <div className="text-center">
            <div className="text-3xl font-bold text-accent-500 mb-1">20+</div>
            <div className="text-sm text-primary-300">精品课程</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent-500 mb-1">200+</div>
            <div className="text-sm text-primary-300">知识点</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent-500 mb-1">50+</div>
            <div className="text-sm text-primary-300">政策解读</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent-500 mb-1">95%</div>
            <div className="text-sm text-primary-300">用户满意度</div>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 0.6 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1 h-3 bg-accent-500 rounded-full mt-2"
          />
        </div>
      </motion.div>
    </section>
  )
}