'use client'

import { motion } from 'framer-motion'

interface ProgressRingProps {
  progress: number // 0-1
  size?: number
  strokeWidth?: number
  color?: string
  backgroundColor?: string
  showPercentage?: boolean
  className?: string
}

export function ProgressRing({
  progress,
  size = 120,
  strokeWidth = 8,
  color = '#F59E0B',
  backgroundColor = '#E5E7EB',
  showPercentage = true,
  className = '',
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDasharray = circumference
  const strokeDashoffset = circumference * (1 - progress)

  const containerVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  }

  const circleVariants = {
    hidden: { strokeDashoffset: circumference },
    visible: {
      strokeDashoffset,
      transition: {
        duration: 1,
        ease: "easeInOut",
      },
    },
  }

  return (
    <motion.div
      className={`relative ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <svg
        width={size}
        height={size}
        className="transform -rotate-90"
        viewBox={`0 0 ${size} ${size}`}
      >
        {/* Background Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={backgroundColor}
          strokeWidth={strokeWidth}
          fill="none"
        />

        {/* Progress Circle */}
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={strokeDasharray}
          variants={circleVariants}
        />
      </svg>

      {/* Center Content */}
      <div className="absolute inset-0 flex items-center justify-center">
        {showPercentage ? (
          <motion.span
            className="text-2xl font-bold text-gray-900 dark:text-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {Math.round(progress * 100)}%
          </motion.span>
        ) : (
          <div className="text-center">
            <motion.div
              className="text-sm font-medium text-gray-900 dark:text-white"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              已完成
            </motion.div>
          </div>
        )}
      </div>
    </motion.div>
  )
}

// Simple progress indicator for linear progress
export function ProgressBar({
  progress,
  color = '#F59E0B',
  backgroundColor = '#E5E7EB',
  height = 4,
  className = '',
}: {
  progress: number
  color?: string
  backgroundColor?: string
  height?: number
  className?: string
}) {
  return (
    <div
      className={`w-full ${className}`}
      style={{
        backgroundColor,
        height: `${height}px`,
        borderRadius: `${height / 2}px`,
        overflow: 'hidden',
      }}
    >
      <motion.div
        className="h-full"
        style={{ backgroundColor }}
        initial={{ width: 0 }}
        animate={{ width: `${progress * 100}%` }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      />
    </div>
  )
}