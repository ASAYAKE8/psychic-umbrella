'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import Fuse from 'fuse.js'
import { Course, KnowledgePoint, Policy, SearchResult } from '@/types'
import coursesData from '@/data/courses.json'
import knowledgeData from '@/data/knowledge.json'
import policiesData from '@/data/policies.json'

const searchOptions = {
  includeScore: true,
  includeMatches: true,
  threshold: 0.3,
  minMatchCharLength: 2,
  keys: [
    { name: 'title', weight: 0.4 },
    { name: 'keyword', weight: 0.3 },
    { name: 'tags', weight: 0.2 },
    { name: 'summary', weight: 0.1 },
  ],
}

export function useSearch() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)

  // 创建搜索索引
  const courseFuse = useMemo(() => new Fuse(coursesData as Course[], searchOptions), [])
  const knowledgeFuse = useMemo(() => new Fuse(knowledgeData as KnowledgePoint[], searchOptions), [])
  const policyFuse = useMemo(() => new Fuse(policiesData as Policy[], searchOptions), [])

  const search = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    setIsSearching(true)

    try {
      // 并行搜索
      const [courseResults, knowledgeResults, policyResults] = await Promise.all([
        courseFuse.search(searchQuery),
        knowledgeFuse.search(searchQuery),
        policyFuse.search(searchQuery),
      ])

      // 合并结果
      const allResults: SearchResult[] = [
        ...courseResults.map(result => ({
          type: 'course' as const,
          item: result.item,
          score: result.score || 0,
          highlights: result.matches?.map(match => ({
            field: match.key || '',
            text: match.value || '',
          })) || [],
        })),
        ...knowledgeResults.map(result => ({
          type: 'kp' as const,
          item: result.item,
          score: result.score || 0,
          highlights: result.matches?.map(match => ({
            field: match.key || '',
            text: match.value || '',
          })) || [],
        })),
        ...policyResults.map(result => ({
          type: 'policy' as const,
          item: result.item,
          score: result.score || 0,
          highlights: result.matches?.map(match => ({
            field: match.key || '',
            text: match.value || '',
          })) || [],
        })),
      ]

      // 按相关性排序
      const sortedResults = allResults
        .sort((a, b) => a.score - b.score)
        .slice(0, 20) // 限制结果数量

      setResults(sortedResults)
    } catch (error) {
      console.error('Search error:', error)
      setResults([])
    } finally {
      setIsSearching(false)
    }
  }, [courseFuse, knowledgeFuse, policyFuse])

  const clearSearch = useCallback(() => {
    setQuery('')
    setResults([])
  }, [])

  // 防抖搜索
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      search(query)
    }, 150)

    return () => clearTimeout(timeoutId)
  }, [query, search])

  return {
    query,
    setQuery,
    results,
    isSearching,
    clearSearch,
  }
}