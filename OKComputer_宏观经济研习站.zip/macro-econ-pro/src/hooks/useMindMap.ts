'use client'

import { useState, useEffect, useRef, useCallback } from 'react'

export interface MindMapNode {
  id: string
  label: string
  x: number
  y: number
  level: number
  children?: MindMapNode[]
  parent?: string
  expanded?: boolean
}

export interface MindMapConfig {
  width: number
  height: number
  nodeSpacing: number
  levelSpacing: number
  animationDuration: number
}

export function useMindMap(initialNodes: MindMapNode[], config: MindMapConfig) {
  const [nodes, setNodes] = useState<MindMapNode[]>(initialNodes)
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const [scale, setScale] = useState(1)
  const [offset, setOffset] = useState({ x: 0, y: 0 })
  const svgRef = useRef<SVGSVGElement>(null)
  const isDragging = useRef(false)
  const dragStart = useRef({ x: 0, y: 0 })

  const toggleNode = useCallback((nodeId: string) => {
    setNodes(prev => prev.map(node => {
      if (node.id === nodeId) {
        return { ...node, expanded: !node.expanded }
      }
      return node
    }))
  }, [])

  const selectNode = useCallback((nodeId: string | null) => {
    setSelectedNode(nodeId)
  }, [])

  const zoomIn = useCallback(() => {
    setScale(prev => Math.min(prev * 1.2, 3))
  }, [])

  const zoomOut = useCallback(() => {
    setScale(prev => Math.max(prev / 1.2, 0.3))
  }, [])

  const resetZoom = useCallback(() => {
    setScale(1)
    setOffset({ x: 0, y: 0 })
  }, [])

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.target === svgRef.current) {
      isDragging.current = true
      dragStart.current = { x: e.clientX - offset.x, y: e.clientY - offset.y }
    }
  }, [offset])

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging.current) {
      setOffset({
        x: e.clientX - dragStart.current.x,
        y: e.clientY - dragStart.current.y,
      })
    }
  }, [])

  const handleMouseUp = useCallback(() => {
    isDragging.current = false
  }, [])

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    setScale(prev => Math.max(0.3, Math.min(prev * delta, 3)))
  }, [])

  const getNodePosition = useCallback((nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId)
    return node ? { x: node.x, y: node.y } : { x: 0, y: 0 }
  }, [nodes])

  const getNodeConnections = useCallback((nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId)
    if (!node) return []
    
    const connections = []
    if (node.parent) {
      connections.push(node.parent)
    }
    if (node.children) {
      connections.push(...node.children.map(child => child.id))
    }
    return connections
  }, [nodes])

  return {
    nodes,
    selectedNode,
    scale,
    offset,
    svgRef,
    toggleNode,
    selectNode,
    zoomIn,
    zoomOut,
    resetZoom,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleWheel,
    getNodePosition,
    getNodeConnections,
  }
}