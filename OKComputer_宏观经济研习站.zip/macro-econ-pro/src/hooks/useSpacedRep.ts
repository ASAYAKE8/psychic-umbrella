'use client'

import { useState, useEffect, useCallback } from 'react'
import { useFavorites } from './useFavorites'
import { calculateNextReview, getTodaysReviewItems, calculateRetentionScore, getLearningProgress } from '@/utils/spaced-repetition'
import { FavoriteItem } from '@/types'

export function useSpacedRep() {
  const { favorites, updateFavoriteProgress } = useFavorites()
  const [todaysItems, setTodaysItems] = useState<FavoriteItem[]>([])
  const [retentionScore, setRetentionScore] = useState(0)
  const [progress, setProgress] = useState({ mastered: 0, learning: 0, new: 0 })

  useEffect(() => {
    const spacedItems = favorites.map(item => ({
      ...item,
      nextReview: new Date(item.nextReview),
      lastReviewed: item.lastReviewed ? new Date(item.lastReviewed) : undefined,
    }))

    const todayItems = getTodaysReviewItems(spacedItems)
    setTodaysItems(todayItems)

    const score = calculateRetentionScore(spacedItems)
    setRetentionScore(score)

    const prog = getLearningProgress(spacedItems)
    setProgress(prog)
  }, [favorites])

  const reviewItem = useCallback((
    itemId: string,
    itemType: FavoriteItem['type'],
    performance: 'again' | 'hard' | 'good' | 'easy'
  ) => {
    const item = favorites.find(f => f.id === itemId && f.type === itemType)
    if (!item) return

    const spacedItem = {
      ...item,
      nextReview: new Date(item.nextReview),
      lastReviewed: item.lastReviewed ? new Date(item.lastReviewed) : undefined,
    }

    const updatedItem = calculateNextReview(spacedItem, performance)
    
    updateFavoriteProgress(itemType, itemId, {
      reviewCount: updatedItem.reviewCount,
      mastery: updatedItem.mastery,
      nextReview: updatedItem.nextReview.toISOString(),
      lastReviewed: updatedItem.lastReviewed?.toISOString(),
    })
  }, [favorites, updateFavoriteProgress])

  const getNextReviewItem = useCallback(() => {
    if (todaysItems.length === 0) return null
    return todaysItems[0]
  }, [todaysItems])

  const skipItem = useCallback((itemId: string, itemType: FavoriteItem['type']) => {
    const item = favorites.find(f => f.id === itemId && f.type === itemType)
    if (!item) return

    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)

    updateFavoriteProgress(itemType, itemId, {
      nextReview: tomorrow.toISOString(),
    })
  }, [favorites, updateFavoriteProgress])

  return {
    todaysItems,
    retentionScore,
    progress,
    reviewItem,
    getNextReviewItem,
    skipItem,
    totalItems: favorites.length,
  }
}