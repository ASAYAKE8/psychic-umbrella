'use client'

import { useState, useEffect, useCallback } from 'react'
import { FavoriteItem } from '@/types'
import { getNextReviewDate } from '@/utils/date-format'

const STORAGE_KEY = 'macro-econ-pro-favorites'

export function useFavorites() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadFavorites = () => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY)
        if (stored) {
          const parsed = JSON.parse(stored)
          setFavorites(parsed)
        }
      } catch (error) {
        console.error('Failed to load favorites:', error)
      } finally {
        setIsLoading(false)
      }
    }

    loadFavorites()
  }, [])

  const saveFavorites = useCallback((items: FavoriteItem[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
    } catch (error) {
      console.error('Failed to save favorites:', error)
    }
  }, [])

  const addFavorite = useCallback((type: FavoriteItem['type'], id: string) => {
    const newItem: FavoriteItem = {
      type,
      id,
      addedAt: new Date().toISOString(),
      reviewCount: 0,
      nextReview: getNextReviewDate(0).toISOString(),
      mastery: 0,
    }

    setFavorites(prev => {
      const exists = prev.some(item => item.id === id && item.type === type)
      if (exists) return prev
      
      const updated = [...prev, newItem]
      saveFavorites(updated)
      return updated
    })
  }, [saveFavorites])

  const removeFavorite = useCallback((type: FavoriteItem['type'], id: string) => {
    setFavorites(prev => {
      const updated = prev.filter(item => !(item.id === id && item.type === type))
      saveFavorites(updated)
      return updated
    })
  }, [saveFavorites])

  const isFavorite = useCallback((type: FavoriteItem['type'], id: string): boolean => {
    return favorites.some(item => item.id === id && item.type === type)
  }, [favorites])

  const updateFavoriteProgress = useCallback((
    type: FavoriteItem['type'],
    id: string,
    updates: Partial<FavoriteItem>
  ) => {
    setFavorites(prev => {
      const updated = prev.map(item => {
        if (item.id === id && item.type === type) {
          return { ...item, ...updates }
        }
        return item
      })
      saveFavorites(updated)
      return updated
    })
  }, [saveFavorites])

  const clearFavorites = useCallback(() => {
    setFavorites([])
    localStorage.removeItem(STORAGE_KEY)
  }, [])

  return {
    favorites,
    isLoading,
    addFavorite,
    removeFavorite,
    isFavorite,
    updateFavoriteProgress,
    clearFavorites,
  }
}