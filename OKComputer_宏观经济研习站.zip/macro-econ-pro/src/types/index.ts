export interface Course {
  id: string
  title: string
  slug: string
  tagline: string
  difficulty: 1 | 2 | 3 | 4 | 5
  duration: number
  category: string
  tags: string[]
  outline: {
    chapter: string
    lessons: string[]
  }[]
  videoURL?: string
  audioURL?: string
  transcriptMDX?: string
  thumbnail?: string
  description: string
  instructor?: string
  publishedAt: string
  updatedAt: string
}

export interface KnowledgePoint {
  id: string
  title: string
  keyword: string[]
  summary: string
  bodyMDX: string
  mindmapSVG?: string
  formula?: string
  chartType?: 'line' | 'bar' | 'pie' | 'scatter'
  relatedCourses: string[]
  relatedPolicies: string[]
  category: string
  difficulty: 1 | 2 | 3 | 4 | 5
  tags: string[]
  createdAt: string
  updatedAt: string
}

export interface Policy {
  id: string
  title: string
  pubDate: string
  issuer: string
  region: '全国' | '华北' | '华东' | '华南' | '西南' | '西北' | '东北' | '华中'
  impact: '高' | '中' | '低'
  abstract: string
  fullURL: string
  relatedKPs: string[]
  category: string
  tags: string[]
  effectiveDate?: string
  expiryDate?: string
}

export interface FavoriteItem {
  type: 'course' | 'kp' | 'policy'
  id: string
  addedAt: string
  reviewCount: number
  nextReview: string
  mastery: number // 0-1
  lastReviewed?: string
}

export interface SearchResult {
  type: 'course' | 'kp' | 'policy'
  item: Course | KnowledgePoint | Policy
  score: number
  highlights: {
    field: string
    text: string
  }[]
}