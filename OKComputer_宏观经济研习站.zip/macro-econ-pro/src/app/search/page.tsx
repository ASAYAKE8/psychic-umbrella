'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Search, X, Filter, Clock, TrendingUp, BookOpen, PlaySquare, FileText } from 'lucide-react'
import { useSearch } from '@/hooks/useSearch'
import { CardCourse } from '@/components/CardCourse'
import { CardKP } from '@/components/CardKP'
import { CardPolicy } from '@/components/CardPolicy'
import Link from 'next/link'

export default function SearchPage() {
  const { query, setQuery, results, isSearching, clearSearch } = useSearch()
  const [selectedType, setSelectedType] = useState<string>('all')
  const [showFilters, setShowFilters] = useState(false)

  // 热门搜索词
  const trendingSearches = [
    'GDP核算',
    '货币政策',
    '通货膨胀',
    '财政政策',
    '汇率机制',
    '经济周期',
    '供给侧改革',
    '数字经济',
  ]

  // 最近搜索（从localStorage获取）
  const [recentSearches, setRecentSearches] = useState<string[]>([])

  useEffect(() => {
    const stored = localStorage.getItem('recent-searches')
    if (stored) {
      setRecentSearches(JSON.parse(stored))
    }
  }, [])

  // 添加搜索到历史
  const addToRecentSearches = (searchTerm: string) => {
    if (!searchTerm.trim()) return
    
    const updated = [searchTerm, ...recentSearches.filter(s => s !== searchTerm)].slice(0, 10)
    setRecentSearches(updated)
    localStorage.setItem('recent-searches', JSON.stringify(updated))
  }

  // 处理搜索提交
  const handleSearchSubmit = (searchTerm: string) => {
    setQuery(searchTerm)
    addToRecentSearches(searchTerm)
  }

  // 清除搜索历史
  const clearRecentSearches = () => {
    setRecentSearches([])
    localStorage.removeItem('recent-searches')
  }

  // 过滤搜索结果
  const filteredResults = results.filter(result => {
    if (selectedType === 'all') return true
    return result.type === selectedType
  })

  // 统计各类型结果数量
  const resultCounts = {
    all: results.length,
    course: results.filter(r => r.type === 'course').length,
    kp: results.filter(r => r.type === 'kp').length,
    policy: results.filter(r => r.type === 'policy').length,
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'course': return PlaySquare
      case 'kp': return BookOpen
      case 'policy': return FileText
      default: return Search
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'course': return '课程'
      case 'kp': return '知识点'
      case 'policy': return '政策'
      default: return '全部'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-primary-900">
      {/* Header */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4 text-center"
          >
            全局搜索
          </motion.h1>
          
          {/* Search Box */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => handleSearchSubmit(e.target.value)}
                placeholder="搜索课程、知识点、政策..."
                className="w-full pl-12 pr-12 py-4 text-lg border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-accent-500"
                autoFocus
              />
              {query && (
                <button
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* No Search Query - Show Suggestions */}
        {!query && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Recent Searches */}
            {recentSearches.length > 0 && (
              <div className="bg-white dark:bg-primary-800 rounded-lg p-6 shadow-card">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    最近搜索
                  </h3>
                  <button
                    onClick={clearRecentSearches}
                    className="text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                  >
                    清除
                  </button>
                </div>
                <div className="space-y-2">
                  {recentSearches.map((search) => (
                    <button
                      key={search}
                      onClick={() => handleSearchSubmit(search)}
                      className="w-full text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Trending Searches */}
            <div className="bg-white dark:bg-primary-800 rounded-lg p-6 shadow-card">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                热门搜索
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {trendingSearches.map((search) => (
                  <button
                    key={search}
                    onClick={() => handleSearchSubmit(search)}
                    className="text-left px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Has Search Query - Show Results */}
        {query && (
          <div>
            {/* Filters and Results Count */}
            <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <span className="text-gray-600 dark:text-gray-400">
                  找到 {filteredResults.length} 个结果
                </span>
                {isSearching && (
                  <span className="text-sm text-gray-500">搜索中...</span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <Filter className="w-4 h-4" />
                  筛选
                </button>

                {/* Type Filters */}
                <div className="flex gap-1">
                  {Object.entries(resultCounts).map(([type, count]) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      disabled={count === 0}
                      className={`px-3 py-2 text-sm rounded-md transition-colors ${
                        selectedType === type
                          ? 'bg-accent-500 text-white'
                          : count === 0
                          ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {getTypeLabel(type)} ({count})
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* No Results */}
            {filteredResults.length === 0 && !isSearching && (
              <div className="text-center py-16">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  未找到相关内容
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  尝试使用其他关键词或调整筛选条件
                </p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <button
                    onClick={() => setSelectedType('all')}
                    className="px-4 py-2 bg-accent-500 hover:bg-accent-600 text-white rounded-lg transition-colors"
                  >
                    清除筛选
                  </button>
                  <button
                    onClick={clearSearch}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    重新搜索
                  </button>
                </div>
              </div>
            )}

            {/* Results Grid */}
            {filteredResults.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResults.map((result, index) => (
                  <motion.div
                    key={`${result.type}-${result.item.id}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    {result.type === 'course' && (
                      <CardCourse course={result.item} />
                    )}
                    {result.type === 'kp' && (
                      <CardKP kp={result.item} />
                    )}
                    {result.type === 'policy' && (
                      <CardPolicy policy={result.item} />
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Search Tips */}
      {query && filteredResults.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 dark:text-blue-300 mb-2">
              搜索技巧
            </h4>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>• 使用关键词搜索，如"GDP"、"货币政策"等</li>
              <li>• 支持模糊匹配，部分匹配也能找到相关内容</li>
              <li>• 可以使用筛选器按类型过滤结果</li>
              <li>• 搜索结果按相关性排序</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}