import { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/ThemeProvider'
import { TopNav } from '@/components/TopNav'
import { Footer } from '@/components/Footer'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: {
    default: 'MacroEcon Pro | 宏观经济研习站',
    template: '%s | MacroEcon Pro',
  },
  description: '洞察宏观，决策先人一步。专业的宏观经济学学习平台，掌握GDP、CPI、利率、汇率等核心知识。',
  keywords: ['宏观经济学', 'GDP', 'CPI', '货币政策', '财政政策', '汇率', '经济学习', '经济学课程'],
  authors: [{ name: 'MacroEcon Pro Team' }],
  creator: 'MacroEcon Pro',
  publisher: 'MacroEcon Pro',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://macro-econ-pro.vercel.app'),
  alternates: {
    canonical: '/',
    types: {
      'application/rss+xml': '/api/rss',
    },
  },
  openGraph: {
    title: 'MacroEcon Pro | 宏观经济研习站',
    description: '洞察宏观，决策先人一步。专业的宏观经济学学习平台。',
    url: 'https://macro-econ-pro.vercel.app',
    siteName: 'MacroEcon Pro',
    images: [
      {
        url: '/og/default.png',
        width: 1200,
        height: 630,
        alt: 'MacroEcon Pro - 宏观经济研习站',
      },
    ],
    locale: 'zh_CN',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MacroEcon Pro | 宏观经济研习站',
    description: '洞察宏观，决策先人一步。专业的宏观经济学学习平台。',
    images: ['/og/default.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <div className="min-h-screen bg-gray-50 dark:bg-primary-900 text-gray-900 dark:text-white transition-colors">
            <TopNav />
            <main className="pt-16">
              {children}
            </main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}