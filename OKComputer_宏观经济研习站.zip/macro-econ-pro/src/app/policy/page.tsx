'use client'

import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Filter, Search, Grid, List, Calendar, MapPin, AlertCircle } from 'lucide-react'
import { CardPolicy } from '@/components/CardPolicy'
import policiesData from '@/data/policies.json'
import { Policy } from '@/types'
import { formatDate } from '@/utils/date-format'

export default function PolicyPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedRegion, setSelectedRegion] = useState<string>('all')
  const [selectedImpact, setSelectedImpact] = useState<string>('all')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState<'date' | 'impact'>('date')

  const regions = useMemo(() => {
    const regs = new Set(policiesData.map(policy => policy.region))
    return Array.from(regs)
  }, [])

  const categories = useMemo(() => {
    const cats = new Set(policiesData.map(policy => policy.category))
    return Array.from(cats)
  }, [])

  const filteredPolicies = useMemo(() => {
    let filtered = policiesData as Policy[]

    // 搜索过滤
    if (searchQuery) {
      filtered = filtered.filter(policy =>
        policy.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        policy.abstract.toLowerCase().includes(searchQuery.toLowerCase()) ||
        policy.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
        policy.issuer.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }

    // 地区过滤
    if (selectedRegion !== 'all') {
      filtered = filtered.filter(policy => policy.region === selectedRegion)
    }

    // 影响度过滤
    if (selectedImpact !== 'all') {
      filtered = filtered.filter(policy => policy.impact === selectedImpact)
    }

    // 分类过滤
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(policy => policy.category === selectedCategory)
    }

    // 排序
    filtered.sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()
      } else if (sortBy === 'impact') {
        const impactOrder = { '高': 3, '中': 2, '低': 1 }
        return impactOrder[b.impact] - impactOrder[a.impact]
      }
      return 0
    })

    return filtered
  }, [searchQuery, selectedRegion, selectedImpact, selectedCategory, sortBy])

  const clearFilters = () => {
    setSearchQuery('')
    setSelectedRegion('all')
    setSelectedImpact('all')
    setSelectedCategory('all')
    setSortBy('date')
  }

  const getImpactStats = () => {
    const stats = { '高': 0, '中': 0, '低': 0 }
    filteredPolicies.forEach(policy => {
      stats[policy.impact]++
    })
    return stats
  }

  const impactStats = getImpactStats()

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-primary-900">
      {/* Header */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4"
            >
              政策雷达
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
            >
              T-0更新，实时追踪政策动态与影响评级
            </motion.p>
          </div>
        </div>
      </div>

      {/* Impact Stats */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-3 gap-6 text-center">
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">高影响</span>
              <span className="font-semibold text-red-600 dark:text-red-400">{impactStats['高']}</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">中影响</span>
              <span className="font-semibold text-orange-600 dark:text-orange-400">{impactStats['中']}</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">低影响</span>
              <span className="font-semibold text-green-600 dark:text-green-400">{impactStats['低']}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="搜索政策..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-accent-500"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3 items-center">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">筛选：</span>
              </div>

              {/* Region Filter */}
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500"
              >
                <option value="all">全部地区</option>
                {regions.map(region => (
                  <option key={region} value={region}>{region}</option>
                ))}
              </select>

              {/* Impact Filter */}
              <select
                value={selectedImpact}
                onChange={(e) => setSelectedImpact(e.target.value)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500"
              >
                <option value="all">全部影响</option>
                <option value="高">高影响</option>
                <option value="中">中影响</option>
                <option value="低">低影响</option>
              </select>

              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500"
              >
                <option value="all">全部分类</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>

              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500"
              >
                <option value="date">发布日期</option>
                <option value="impact">影响程度</option>
              </select>

              {/* View Mode */}
              <div className="flex items-center gap-1 border border-gray-300 dark:border-gray-600 rounded-md p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-1 rounded ${viewMode === 'grid' ? 'bg-accent-500 text-white' : 'text-gray-500 hover:text-gray-700'}`}
                  aria-label="网格视图"
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-1 rounded ${viewMode === 'list' ? 'bg-accent-500 text-white' : 'text-gray-500 hover:text-gray-700'}`}
                  aria-label="列表视图"
                >
                  <List className="w-4 h-4" />
                </button>
              </div>

              {/* Clear Filters */}
              {(searchQuery || selectedRegion !== 'all' || selectedImpact !== 'all' || selectedCategory !== 'all') && (
                <button
                  onClick={clearFilters}
                  className="px-3 py-1 text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  清除筛选
                </button>
              )}
            </div>
          </div>

          {/* Results Count */}
          <div className="mt-4 text-sm text-gray-600 dark:text-gray-400">
            找到 {filteredPolicies.length} 条政策
          </div>
        </div>
      </div>

      {/* Policy Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {filteredPolicies.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">📋</div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              未找到相关政策
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              尝试调整搜索条件或筛选器
            </p>
            <button
              onClick={clearFilters}
              className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              清除筛选条件
            </button>
          </div>
        ) : (
          <div className={`grid gap-8 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1'
          }`}>
            {filteredPolicies.map((policy, index) => (
              <CardPolicy key={policy.id} policy={policy} index={index} />
            ))}
          </div>
        )}
      </div>

      {/* Stats Section */}
      <div className="bg-white dark:bg-primary-800 border-t border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-accent-500 mb-2">
                {policiesData.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                政策总数
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-500 mb-2">
                {regions.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                覆盖地区
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-500 mb-2">
                {categories.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                政策分类
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-500 mb-2">
                T-0
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                更新频率
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}