'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, BookOpen, PlaySquare, FileText, Trash2, Clock, Target } from 'lucide-react'
import { useFavorites } from '@/hooks/useFavorites'
import { useSpacedRep } from '@/hooks/useSpacedRep'
import { CardCourse } from '@/components/CardCourse'
import { CardKP } from '@/components/CardKP'
import { CardPolicy } from '@/components/CardPolicy'
import { ProgressRing } from '@/components/ProgressRing'
import { SpacedRepetition } from '@/components/SpacedRepetition'
import coursesData from '@/data/courses.json'
import knowledgeData from '@/data/knowledge.json'
import policiesData from '@/data/policies.json'
import { formatRelativeTime } from '@/utils/date-format'

type TabType = 'all' | 'courses' | 'kp' | 'policy' | 'review'

export default function FavoritesPage() {
  const { favorites, removeFavorite, clearFavorites } = useFavorites()
  const { retentionScore, progress } = useSpacedRep()
  const [activeTab, setActiveTab] = useState<TabType>('all')
  const [showClearConfirm, setShowClearConfirm] = useState(false)

  const getItemData = (type: string, id: string) => {
    switch (type) {
      case 'course':
        return coursesData.find(course => course.id === id)
      case 'kp':
        return knowledgeData.find(kp => kp.id === id)
      case 'policy':
        return policiesData.find(policy => policy.id === id)
      default:
        return null
    }
  }

  const renderItem = (item: any) => {
    const data = getItemData(item.type, item.id)
    if (!data) return null

    switch (item.type) {
      case 'course':
        return <CardCourse key={item.id} course={data} />
      case 'kp':
        return <CardKP key={item.id} kp={data} />
      case 'policy':
        return <CardPolicy key={item.id} policy={data} />
      default:
        return null
    }
  }

  const filteredFavorites = favorites.filter(item => {
    if (activeTab === 'all') return true
    if (activeTab === 'review') return true
    return item.type === activeTab
  })

  const tabs = [
    { id: 'all', label: '全部', icon: Heart, count: favorites.length },
    { id: 'courses', label: '课程', icon: PlaySquare, count: favorites.filter(f => f.type === 'course').length },
    { id: 'kp', label: '知识点', icon: BookOpen, count: favorites.filter(f => f.type === 'kp').length },
    { id: 'policy', label: '政策', icon: FileText, count: favorites.filter(f => f.type === 'policy').length },
    { id: 'review', label: '复习', icon: Target, count: favorites.length },
  ]

  const handleClearAll = () => {
    clearFavorites()
    setShowClearConfirm(false)
  }

  if (favorites.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-primary-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="text-6xl mb-8">💔</div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              收藏夹空空如也
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
              空空如也？先去点亮♡，让复习开始。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => window.location.href = '/courses'}
                className="bg-accent-500 hover:bg-accent-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                <PlaySquare className="w-5 h-5" />
                浏览课程
              </button>
              <button
                onClick={() => window.location.href = '/knowledge'}
                className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                探索知识库
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-primary-900">
      {/* Header */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4"
              >
                我的收藏
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-lg text-gray-600 dark:text-gray-400"
              >
                已收藏 {favorites.length} 项内容，记忆保留率 {Math.round(retentionScore * 100)}%
              </motion.p>
            </div>

            {/* Progress Ring */}
            <div className="hidden md:block">
              <ProgressRing
                progress={retentionScore}
                size={120}
                color="#10B981"
                showPercentage={true}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex gap-1 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'text-accent-600 dark:text-accent-400 border-b-2 border-accent-500'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                  {tab.count > 0 && (
                    <span className="ml-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs px-2 py-1 rounded-full">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Clear All Button */}
            <button
              onClick={() => setShowClearConfirm(true)}
              className="text-sm text-gray-500 hover:text-red-600 dark:hover:text-red-400 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-4 h-4" />
              清空收藏
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'review' ? (
          <SpacedRepetition />
        ) : (
          <div>
            {/* Study Progress */}
            {activeTab === 'all' && (
              <div className="bg-white dark:bg-primary-800 rounded-lg p-6 mb-8 shadow-card">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">学习进度</h3>
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500 mb-1">{progress.mastered}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">已掌握</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-500 mb-1">{progress.learning}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">学习中</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-500 mb-1">{progress.new}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">新内容</div>
                  </div>
                </div>
              </div>
            )}

            {/* Items Grid */}
            {filteredFavorites.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-6xl mb-4">
                  {activeTab === 'courses' && '📚'}
                  {activeTab === 'kp' && '🧠'}
                  {activeTab === 'policy' && '📋'}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  暂无{activeTab === 'courses' ? '课程' : activeTab === 'kp' ? '知识点' : '政策'}收藏
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  去发现和收藏更多优质内容
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredFavorites.map((item, index) => (
                  <motion.div
                    key={`${item.type}-${item.id}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative"
                  >
                    {renderItem(item)}
                    
                    {/* Study Info */}
                    <div className="absolute top-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-xs">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{formatRelativeTime(item.addedAt)}</span>
                      </div>
                      {item.reviewCount > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <Target className="w-3 h-3" />
                          <span>复习{item.reviewCount}次</span>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Clear Confirmation Modal */}
      <AnimatePresence>
        {showClearConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full"
            >
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  确认清空收藏？
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  此操作将删除所有收藏内容，包括学习进度。此操作不可撤销。
                </p>
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    取消
                  </button>
                  <button
                    onClick={handleClearAll}
                    className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
                  >
                    确认清空
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}