'use client'

import { motion } from 'framer-motion'
import { Github, Mail, Shield, Users, BookOpen, Target, Zap } from 'lucide-react'
import Link from 'next/link'

export default function AboutPage() {
  const features = [
    {
      icon: BookOpen,
      title: '系统学习',
      description: '从基础概念到高级理论，循序渐进的学习路径'
    },
    {
      icon: Target,
      title: '精准定位',
      description: '针对中国宏观经济特点，本土化内容设计'
    },
    {
      icon: Zap,
      title: '实时更新',
      description: '政策动态实时追踪，确保内容时效性'
    }
  ]

  const team = [
    {
      name: '李教授',
      role: '首席经济学家',
      expertise: '宏观经济理论与政策分析'
    },
    {
      name: '王博士',
      role: '课程设计师',
      expertise: '教育技术与学习体验'
    },
    {
      name: '张研究员',
      role: '政策分析师',
      expertise: '货币政策与金融监管'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-primary-900">
      {/* Hero Section */}
      <section className="bg-white dark:bg-primary-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            关于我们
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            MacroEcon Pro 致力于成为最专业的宏观经济学学习平台，帮助学习者深入理解经济运行规律，提升决策能力。
          </motion.p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-3xl font-bold text-gray-900 dark:text-white mb-6"
              >
                我们的使命
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="space-y-4 text-gray-600 dark:text-gray-400"
              >
                <p>
                  在快速变化的全球经济环境中，掌握宏观经济知识变得至关重要。MacroEcon Pro 
                  通过系统化的课程设计、实时的政策追踪和科学的学习方法，帮助学习者建立扎实的宏观经济学基础。
                </p>
                <p>
                  我们相信，每个人都应该有机会理解经济的运行机制。无论是学生、从业者还是决策者，
                  都能在这里找到适合自己的学习内容和工具。
                </p>
                <p>
                  洞察宏观，决策先人一步。这不仅是我们的口号，更是我们对每一位学习者的承诺。
                </p>
              </motion.div>
            </div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white dark:bg-primary-800 rounded-2xl p-8 shadow-card"
            >
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                平台特色
              </h3>
              <div className="space-y-6">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent-100 dark:bg-accent-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <feature.icon className="w-6 h-6 text-accent-600 dark:text-accent-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 dark:text-white mb-1">
                        {feature.title}
                      </h4>
                      <p className="text-gray-600 dark:text-gray-400 text-sm">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-white dark:bg-primary-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              核心团队
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              由经济学专家、教育技术专家和政策分析师组成的专业团队
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-gradient-to-br from-accent-500 to-accent-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-1">
                  {member.name}
                </h3>
                <p className="text-accent-600 dark:text-accent-400 font-medium mb-2">
                  {member.role}
                </p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {member.expertise}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              我们的价值观
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: '专业性', desc: '基于权威理论和实践经验' },
              { title: '易理解', desc: '复杂概念简单化表达' },
              { title: '时效性', desc: '紧跟政策和市场变化' },
              { title: '开放性', desc: '开源共享，持续改进' },
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white dark:bg-primary-800 rounded-lg p-6 text-center shadow-card"
              >
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {value.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {value.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-white dark:bg-primary-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              联系我们
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
              有任何问题、建议或合作意向，欢迎与我们联系
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                  <Mail className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">邮箱联系</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-2">一般咨询与合作</p>
                <a href="mailto:contact@macro-econ-pro.com" className="text-accent-600 dark:text-accent-400 hover:underline">
                  contact@macro-econ-pro.com
                </a>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mb-4">
                  <Github className="w-8 h-8 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">开源项目</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-2">代码贡献与技术支持</p>
                <a href="https://github.com/your-org/macro-econ-pro" className="text-accent-600 dark:text-accent-400 hover:underline">
                  GitHub Repository
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16 bg-gradient-to-r from-primary-900 to-primary-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-white mb-6">
              开始您的学习之旅
            </h2>
            <p className="text-xl text-primary-300 mb-8">
              加入MacroEcon Pro，掌握宏观经济学核心知识
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/courses"
                className="bg-accent-500 hover:bg-accent-600 text-white px-8 py-4 rounded-lg font-semibold transition-colors"
              >
                开始学习
              </Link>
              <Link
                href="/knowledge"
                className="border-2 border-white/30 hover:border-white text-white px-8 py-4 rounded-lg font-semibold transition-colors hover:bg-white/10"
              >
                浏览知识库
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Legal */}
      <section className="py-12 bg-gray-50 dark:bg-primary-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white dark:bg-primary-800 rounded-lg p-8 shadow-card">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              法律声明
            </h3>
            <div className="space-y-4 text-sm text-gray-600 dark:text-gray-400">
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">知识产权</h4>
                <p>
                  本平台内容受著作权法保护，未经授权不得转载或使用。引用内容请注明出处。
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">免责声明</h4>
                <p>
                  本平台提供的学习内容仅供教育目的使用，不构成投资建议。学习者应结合自身情况谨慎决策。
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">隐私政策</h4>
                <p>
                  我们重视用户隐私，不会收集敏感个人信息。学习数据仅用于改善用户体验。
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}