export interface SpacedRepetitionItem {
  id: string
  type: 'course' | 'kp' | 'policy'
  reviewCount: number
  mastery: number // 0-1
  lastReviewed?: Date
  nextReview: Date
}

export function calculateNextReview(
  item: SpacedRepetitionItem,
  performance: 'again' | 'hard' | 'good' | 'easy'
): SpacedRepetitionItem {
  const intervals = [1, 3, 7, 15, 30, 90, 180] // 天数
  
  let newReviewCount = item.reviewCount
  let newMastery = item.mastery
  let nextInterval: number
  
  switch (performance) {
    case 'again':
      newReviewCount = Math.max(0, item.reviewCount - 1)
      newMastery = Math.max(0, item.mastery - 0.2)
      nextInterval = 1
      break
    case 'hard':
      newReviewCount = item.reviewCount
      newMastery = Math.max(0, item.mastery - 0.1)
      nextInterval = intervals[Math.min(newReviewCount, intervals.length - 1)] * 0.8
      break
    case 'good':
      newReviewCount = item.reviewCount + 1
      newMastery = Math.min(1, item.mastery + 0.1)
      nextInterval = intervals[Math.min(newReviewCount - 1, intervals.length - 1)]
      break
    case 'easy':
      newReviewCount = item.reviewCount + 2
      newMastery = Math.min(1, item.mastery + 0.2)
      nextInterval = intervals[Math.min(newReviewCount - 1, intervals.length - 1)] * 1.3
      break
    default:
      nextInterval = 1
  }
  
  const nextReview = new Date()
  nextReview.setDate(nextReview.getDate() + Math.round(nextInterval))
  
  return {
    ...item,
    reviewCount: newReviewCount,
    mastery: newMastery,
    lastReviewed: new Date(),
    nextReview
  }
}

export function getTodaysReviewItems(items: SpacedRepetitionItem[]): SpacedRepetitionItem[] {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)
  
  return items.filter(item => {
    const reviewDate = new Date(item.nextReview)
    reviewDate.setHours(0, 0, 0, 0)
    return reviewDate <= today
  })
}

export function calculateRetentionScore(items: SpacedRepetitionItem[]): number {
  if (items.length === 0) return 0
  
  const totalMastery = items.reduce((sum, item) => sum + item.mastery, 0)
  return totalMastery / items.length
}

export function getLearningProgress(items: SpacedRepetitionItem[]): {
  mastered: number
  learning: number
  new: number
} {
  return items.reduce(
    (acc, item) => {
      if (item.mastery >= 0.8) acc.mastered++
      else if (item.reviewCount > 0) acc.learning++
      else acc.new++
      return acc
    },
    { mastered: 0, learning: 0, new: 0 }
  )
}