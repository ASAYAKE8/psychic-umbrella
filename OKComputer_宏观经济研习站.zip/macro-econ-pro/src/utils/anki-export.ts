import JSZip from 'jszip'

interface AnkiCard {
  front: string
  back: string
  tags: string[]
}

export async function generateAnkiDeck(cards: AnkiCard[], deckName: string): Promise<Blob> {
  const zip = new JSZip()
  
  // 创建Anki导入格式的文本文件
  const ankiText = cards.map(card => {
    const front = card.front.replace(/\n/g, '<br>')
    const back = card.back.replace(/\n/g, '<br>')
    const tags = card.tags.join(' ')
    return `${front}\t${back}\t${tags}`
  }).join('\n')
  
  zip.file(`${deckName}.txt`, ankiText)
  
  // 添加说明文件
  const readme = `# ${deckName}\n\n## 导入说明\n\n1. 打开Anki\n2. 点击"导入文件"\n3. 选择${deckName}.txt文件\n4. 设置导入选项\n5. 点击"导入"\n\n## 卡片格式\n\n- 正面：知识点标题\n- 背面：核心内容（不超过3行）\n- 标签：相关分类\n\n## 学习建议\n\n- 每天复习5-10张卡片\n- 使用间隔重复算法\n- 结合实际案例理解\n`
  
  zip.file('README.md', readme)
  
  const blob = await zip.generateAsync({ type: 'blob' })
  return blob
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}