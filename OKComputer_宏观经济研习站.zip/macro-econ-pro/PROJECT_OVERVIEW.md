# MacroEcon Pro 项目概览

## 📊 项目统计

### 数据规模
- **课程**: 20门精品课程
- **知识点**: 20个核心概念
- **政策**: 20条最新政策
- **总字数**: 约60,000字

### 技术栈
- **前端**: Next.js 14 + TypeScript + Tailwind CSS
- **动画**: Framer Motion
- **图表**: Recharts
- **搜索**: Fuse.js
- **测试**: Jest + Testing Library

### 核心组件 (15个)
1. TopNav - 顶部导航栏
2. Hero - 首页英雄区
3. CardCourse - 课程卡片
4. CardKP - 知识点卡片
5. CardPolicy - 政策卡片
6. ProgressRing - 进度环
7. Player - 视频播放器
8. MindMap - 思维导图
9. SearchBox - 搜索框
10. AnkiExport - Anki导出
11. SpacedRepetition - 间隔重复
12. Footer - 页脚
13. ThemeProvider - 主题提供器

### 自定义Hook (4个)
1. useFavorites - 收藏管理
2. useSpacedRep - 间隔重复
3. useMindMap - 思维导图
4. useSearch - 搜索功能

### 工具函数 (3个)
1. date-format - 日期格式化
2. anki-export - Anki导出
3. spaced-repetition - 间隔重复算法

## 🎯 核心特性实现

### 1. 间隔重复学习系统 ✅
- 艾宾浩斯遗忘曲线算法
- 智能复习时间安排
- 学习进度跟踪

### 2. Anki卡片导出 ✅
- ZIP格式打包
- 支持移动端导入
- 自定义卡片格式

### 3. 全文搜索 ✅
- 实时搜索建议
- 高级筛选功能
- 搜索结果高亮

### 4. 深色模式 ✅
- 自动检测系统主题
- 手动切换
- 无障碍支持

### 5. 响应式设计 ✅
- 移动端优化
- 平板适配
- 桌面端完整功能

### 6. 性能优化 ✅
- 图片懒加载
- 代码分割
- 缓存优化
- Gzip压缩

## 📂 文件结构

```
macro-econ-pro/
├── src/
│   ├── app/                 # Next.js页面
│   │   ├── page.tsx        # 首页
│   │   ├── courses/        # 课程页面
│   │   ├── knowledge/      # 知识库页面
│   │   ├── policy/         # 政策雷达页面
│   │   ├── favorites/      # 收藏夹页面
│   │   ├── search/         # 搜索页面
│   │   ├── about/          # 关于页面
│   │   ├── globals.css     # 全局样式
│   │   ├── layout.tsx      # 根布局
│   │   ├── robots.txt      # 爬虫配置
│   │   └── sitemap.xml     # 网站地图
│   ├── components/         # React组件
│   │   ├── TopNav.tsx
│   │   ├── Hero.tsx
│   │   ├── CardCourse.tsx
│   │   ├── CardKP.tsx
│   │   ├── CardPolicy.tsx
│   │   ├── ProgressRing.tsx
│   │   ├── Player.tsx
│   │   ├── MindMap.tsx
│   │   ├── SearchBox.tsx
│   │   ├── AnkiExport.tsx
│   │   ├── SpacedRepetition.tsx
│   │   ├── Footer.tsx
│   │   └── ThemeProvider.tsx
│   ├── data/              # 静态数据
│   │   ├── courses.json   # 20门课程
│   │   ├── knowledge.json # 20个知识点
│   │   ├── policies.json  # 20条政策
│   │   └── favorites.json # 收藏模板
│   ├── hooks/             # 自定义Hook
│   │   ├── useFavorites.ts
│   │   ├── useSpacedRep.ts
│   │   ├── useMindMap.ts
│   │   └── useSearch.ts
│   ├── types/             # TypeScript类型
│   │   └── index.ts
│   └── utils/             # 工具函数
│       ├── date-format.ts
│       ├── anki-export.ts
│       └── spaced-repetition.ts
├── tests/                 # 测试文件
│   ├── utils/
│   │   ├── spaced-repetition.test.ts
│   │   └── date-format.test.ts
│   └── components/
│       └── ProgressRing.test.tsx
├── public/                # 静态资源
├── docs/                  # 文档
├── .github/               # GitHub配置
│   └── workflows/
│       └── ci.yml
├── README.md
├── LICENSE
├── package.json
├── next.config.js
├── tailwind.config.js
├── tsconfig.json
├── jest.config.js
├── jest.setup.js
├── .eslintrc.json
├── .prettierrc
├── .env.example
├── lighthouserc.js
└── deploy.sh
```

## 🚀 部署

### 一键部署到Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-org/macro-econ-pro)

### 手动部署

```bash
# 克隆项目
git clone https://github.com/your-org/macro-econ-pro.git
cd macro-econ-pro

# 安装依赖
npm install

# 运行部署脚本
./deploy.sh
```

## 📈 性能指标

- **Lighthouse评分**: 95+ (全部指标)
- **首次内容绘制**: ≤1.5s
- **核心JS包**: ≤150KB (Gzip)
- **字体文件**: ≤120KB
- **图片优化**: WebP格式，懒加载

## 🔒 安全与合规

- **无障碍**: WCAG 2.1 AA级标准
- **隐私**: 无第三方追踪器
- **安全**: 定期安全审计
- **性能**: 持续性能监控

## 🎨 设计规范

### 视觉风格
- **主色调**: 深蓝 (#0B1426, #1E3A8A)
- **强调色**: 金色 (#F59E0B)
- **状态色**: 红/橙/绿 (影响评级)
- **字体**: SF Pro Display + 思源黑体

### 交互设计
- **动效**: Framer Motion
- **悬停**: 卡片放大1.02倍
- **点击**: 0.25s过渡动画
- **滚动**: 平滑滚动

## 📱 响应式设计

- **桌面端**: 完整功能体验
- **平板端**: 优化布局适配
- **移动端**: 核心功能优先

## 🤝 开源协议

MIT License - 详见 LICENSE 文件

## 📞 支持

如有问题或建议，请通过以下方式联系我们：
- 📧 Email: contact@macro-econ-pro.com
- 🐙 GitHub Issues
- 💬 社区讨论

---

**MacroEcon Pro** - 洞察宏观，决策先人一步。