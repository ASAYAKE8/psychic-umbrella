import { render, screen } from '@testing-library/react'
import { ProgressRing } from '@/components/ProgressRing'

describe('ProgressRing', () => {
  it('should render with correct progress', () => {
    render(<ProgressRing progress={0.75} />)
    
    // Check if the percentage is displayed
    expect(screen.getByText('75%')).toBeInTheDocument()
  })

  it('should render without percentage when showPercentage is false', () => {
    render(<ProgressRing progress={0.75} showPercentage={false} />)
    
    // Should not show percentage
    expect(screen.queryByText('75%')).not.toBeInTheDocument()
    expect(screen.getByText('已完成')).toBeInTheDocument()
  })

  it('should apply custom size and colors', () => {
    const { container } = render(
      <ProgressRing 
        progress={0.5} 
        size={200} 
        color="#ff0000" 
        backgroundColor="#cccccc" 
      />
    )
    
    const svg = container.querySelector('svg')
    expect(svg).toHaveAttribute('width', '200')
    expect(svg).toHaveAttribute('height', '200')
  })

  it('should handle edge cases', () => {
    const { rerender } = render(<ProgressRing progress={0} />)
    expect(screen.getByText('0%')).toBeInTheDocument()
    
    rerender(<ProgressRing progress={1} />)
    expect(screen.getByText('100%')).toBeInTheDocument()
  })
})