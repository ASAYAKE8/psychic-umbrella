import { formatDate, formatDateTime, formatRelativeTime, getNextReviewDate } from '@/utils/date-format'

describe('Date Format Utils', () => {
  describe('formatDate', () => {
    it('should format date correctly', () => {
      const date = new Date('2024-01-15')
      const result = formatDate(date)
      expect(result).toBe('2024-01-15')
    })

    it('should handle string input', () => {
      const result = formatDate('2024-01-15')
      expect(result).toBe('2024-01-15')
    })

    it('should pad single digits with zeros', () => {
      const date = new Date('2024-01-05')
      const result = formatDate(date)
      expect(result).toBe('2024-01-05')
    })
  })

  describe('formatDateTime', () => {
    it('should format datetime correctly', () => {
      const date = new Date('2024-01-15T14:30:00')
      const result = formatDateTime(date)
      expect(result).toBe('2024-01-15 14:30')
    })

    it('should handle string input', () => {
      const result = formatDateTime('2024-01-15T14:30:00')
      expect(result).toBe('2024-01-15 14:30')
    })

    it('should pad hours and minutes with zeros', () => {
      const date = new Date('2024-01-15T09:05:00')
      const result = formatDateTime(date)
      expect(result).toBe('2024-01-15 09:05')
    })
  })

  describe('formatRelativeTime', () => {
    const now = new Date()

    it('should return "刚刚" for very recent times', () => {
      const recent = new Date(now.getTime() - 30 * 1000) // 30 seconds ago
      const result = formatRelativeTime(recent)
      expect(result).toBe('刚刚')
    })

    it('should return minutes ago for recent times', () => {
      const minutesAgo = new Date(now.getTime() - 5 * 60 * 1000) // 5 minutes ago
      const result = formatRelativeTime(minutesAgo)
      expect(result).toBe('5分钟前')
    })

    it('should return hours ago for today times', () => {
      const hoursAgo = new Date(now.getTime() - 3 * 60 * 60 * 1000) // 3 hours ago
      const result = formatRelativeTime(hoursAgo)
      expect(result).toBe('3小时前')
    })

    it('should return days ago for older times', () => {
      const daysAgo = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
      const result = formatRelativeTime(daysAgo)
      expect(result).toBe('2天前')
    })

    it('should handle string input', () => {
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      const result = formatRelativeTime(yesterday.toISOString())
      expect(result).toBe('1天前')
    })
  })

  describe('getNextReviewDate', () => {
    it('should return date in the future', () => {
      const now = new Date()
      const result = getNextReviewDate(0)
      expect(result.getTime()).toBeGreaterThan(now.getTime())
    })

    it('should return correct interval for review count', () => {
      const intervals = [1, 3, 7, 15, 30, 90]
      
      intervals.forEach((expectedDays, index) => {
        const result = getNextReviewDate(index)
        const now = new Date()
        const diffTime = result.getTime() - now.getTime()
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
        
        // Allow for some margin due to timing
        expect(diffDays).toBeGreaterThanOrEqual(expectedDays - 1)
        expect(diffDays).toBeLessThanOrEqual(expectedDays + 1)
      })
    })

    it('should handle review count beyond intervals array', () => {
      const result = getNextReviewDate(100) // Beyond array length
      const now = new Date()
      const diffTime = result.getTime() - now.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      
      // Should use last interval (90 days)
      expect(diffDays).toBeGreaterThanOrEqual(89)
      expect(diffDays).toBeLessThanOrEqual(91)
    })
  })
})