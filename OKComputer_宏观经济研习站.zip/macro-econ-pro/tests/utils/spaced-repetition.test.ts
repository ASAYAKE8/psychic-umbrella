import { calculateNextReview, getTodaysReviewItems, calculateRetentionScore, getLearningProgress } from '@/utils/spaced-repetition'
import { SpacedRepetitionItem } from '@/utils/spaced-repetition'

describe('Spaced Repetition Utils', () => {
  describe('calculateNextReview', () => {
    const baseItem: SpacedRepetitionItem = {
      id: 'test-1',
      type: 'kp',
      reviewCount: 0,
      mastery: 0.5,
      nextReview: new Date(),
    }

    it('should handle "again" performance correctly', () => {
      const result = calculateNextReview(baseItem, 'again')
      
      expect(result.reviewCount).toBe(0)
      expect(result.mastery).toBe(0.3) // 0.5 - 0.2
      expect(result.nextReview.getTime()).toBeLessThanOrEqual(new Date().getTime() + 24 * 60 * 60 * 1000)
    })

    it('should handle "hard" performance correctly', () => {
      const result = calculateNextReview(baseItem, 'hard')
      
      expect(result.reviewCount).toBe(0)
      expect(result.mastery).toBe(0.4) // 0.5 - 0.1
      expect(result.nextReview.getTime()).toBeGreaterThan(new Date().getTime())
    })

    it('should handle "good" performance correctly', () => {
      const result = calculateNextReview(baseItem, 'good')
      
      expect(result.reviewCount).toBe(1)
      expect(result.mastery).toBe(0.6) // 0.5 + 0.1
      expect(result.nextReview.getTime()).toBeGreaterThan(new Date().getTime())
    })

    it('should handle "easy" performance correctly', () => {
      const result = calculateNextReview(baseItem, 'easy')
      
      expect(result.reviewCount).toBe(2)
      expect(result.mastery).toBe(0.7) // 0.5 + 0.2
      expect(result.nextReview.getTime()).toBeGreaterThan(new Date().getTime())
    })

    it('should ensure mastery stays within 0-1 range', () => {
      const highMasteryItem = { ...baseItem, mastery: 0.9 }
      const result1 = calculateNextReview(highMasteryItem, 'easy')
      expect(result1.mastery).toBe(1)

      const lowMasteryItem = { ...baseItem, mastery: 0.1 }
      const result2 = calculateNextReview(lowMasteryItem, 'again')
      expect(result2.mastery).toBe(0)
    })
  })

  describe('getTodaysReviewItems', () => {
    it('should return items due for review today', () => {
      const today = new Date()
      const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000)
      const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000)

      const items: SpacedRepetitionItem[] = [
        { id: '1', type: 'kp', reviewCount: 1, mastery: 0.5, nextReview: today },
        { id: '2', type: 'kp', reviewCount: 1, mastery: 0.5, nextReview: yesterday },
        { id: '3', type: 'kp', reviewCount: 1, mastery: 0.5, nextReview: tomorrow },
      ]

      const result = getTodaysReviewItems(items)
      
      expect(result).toHaveLength(2)
      expect(result.map(item => item.id)).toContain('1')
      expect(result.map(item => item.id)).toContain('2')
      expect(result.map(item => item.id)).not.toContain('3')
    })
  })

  describe('calculateRetentionScore', () => {
    it('should calculate average mastery correctly', () => {
      const items: SpacedRepetitionItem[] = [
        { id: '1', type: 'kp', reviewCount: 1, mastery: 0.8, nextReview: new Date() },
        { id: '2', type: 'kp', reviewCount: 1, mastery: 0.6, nextReview: new Date() },
        { id: '3', type: 'kp', reviewCount: 1, mastery: 0.4, nextReview: new Date() },
      ]

      const result = calculateRetentionScore(items)
      expect(result).toBe(0.6) // (0.8 + 0.6 + 0.4) / 3
    })

    it('should return 0 for empty array', () => {
      const result = calculateRetentionScore([])
      expect(result).toBe(0)
    })
  })

  describe('getLearningProgress', () => {
    it('should categorize items correctly', () => {
      const items: SpacedRepetitionItem[] = [
        { id: '1', type: 'kp', reviewCount: 3, mastery: 0.9, nextReview: new Date() }, // mastered
        { id: '2', type: 'kp', reviewCount: 2, mastery: 0.7, nextReview: new Date() }, // mastered
        { id: '3', type: 'kp', reviewCount: 2, mastery: 0.5, nextReview: new Date() }, // learning
        { id: '4', type: 'kp', reviewCount: 1, mastery: 0.3, nextReview: new Date() }, // learning
        { id: '5', type: 'kp', reviewCount: 0, mastery: 0.1, nextReview: new Date() }, // new
        { id: '6', type: 'kp', reviewCount: 0, mastery: 0.0, nextReview: new Date() }, // new
      ]

      const result = getLearningProgress(items)
      
      expect(result.mastered).toBe(2)
      expect(result.learning).toBe(2)
      expect(result.new).toBe(2)
    })
  })
})