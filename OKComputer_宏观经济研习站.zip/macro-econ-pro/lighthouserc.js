module.exports = {
  ci: {
    collect: {
      startServerCommand: 'npm start',
      url: ['http://localhost:3000/'],
      numberOfRuns: 3,
    },
    assert: {
      assertions: {
        'categories:performance': ['error', { minScore: 90 }],
        'categories:accessibility': ['error', { minScore: 95 }],
        'categories:best-practices': ['error', { minScore: 95 }],
        'categories:seo': ['error', { minScore: 95 }],
        'categories:pwa': ['warn', { minScore: 90 }],
      },
    },
    upload: {
      target: 'temporary-public-storage',
    },
  },
}